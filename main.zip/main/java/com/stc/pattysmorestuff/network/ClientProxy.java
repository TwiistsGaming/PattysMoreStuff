package com.stc.pattysmorestuff.network;

import com.stc.pattysmorestuff.PattysMoreStuff;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.model.obj.OBJLoader;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;

@Mod.EventBusSubscriber(Dist.CLIENT)
public class ClientProxy implements IProxy {

    @Override
    public void setup (FMLCommonSetupEvent event) {
        OBJLoader.INSTANCE.equals(PattysMoreStuff.MODID);
        //ClientRegistry.bindTileEntityRenderer(ModTileEntities.RED_JAR, RenderJarRed::new);
    }

    @Override
    public PlayerEntity getClientPlayer() {
        return Minecraft.getInstance().player;
    }

    @Override
    public World getClientWorld()
    {
        return Minecraft.getInstance().world;
    }
}
