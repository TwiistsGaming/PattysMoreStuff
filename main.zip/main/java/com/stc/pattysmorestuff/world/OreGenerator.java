package com.stc.pattysmorestuff.world;

import com.stc.pattysmorestuff.config.ConfigGeneral;
import com.stc.pattysmorestuff.init.ModBlocks;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.gen.GenerationStage;
import net.minecraft.world.gen.blockplacer.SimpleBlockPlacer;
import net.minecraft.world.gen.blockstateprovider.WeightedBlockStateProvider;
import net.minecraft.world.gen.feature.*;
import net.minecraft.world.gen.placement.*;
import net.minecraftforge.registries.ForgeRegistries;
import static net.minecraft.world.gen.feature.OreFeatureConfig.FillerBlockType.NATURAL_STONE;
import static net.minecraft.world.gen.feature.OreFeatureConfig.FillerBlockType.NETHERRACK;
import static net.minecraft.world.gen.placement.Placement.COUNT_RANGE;

public class OreGenerator {

    //private static final EndOreFeature END_OREGEN = new EndOreFeature(null);

    public static void setupOreGen() {

        for (Biome biome : ForgeRegistries.BIOMES) {

            if(ConfigGeneral.disableWildCrop.get()) {
                BlockClusterFeatureConfig featureConfigGrass = (new BlockClusterFeatureConfig.Builder((new WeightedBlockStateProvider()).addWeightedBlockstate(ModBlocks.wild_crop.getDefaultState(), 1), new SimpleBlockPlacer())).tries(ConfigGeneral.wildCropChance.get()).build();
                biome.addFeature(GenerationStage.Decoration.TOP_LAYER_MODIFICATION, Feature.FLOWER.withConfiguration(featureConfigGrass).withPlacement(Placement.COUNT_HEIGHTMAP_DOUBLE.configure(new FrequencyConfig(2))));
            }
            if(ConfigGeneral.disableOres.get()) {
                //Overworld Ores
                biome.addFeature(GenerationStage.Decoration.UNDERGROUND_ORES, Feature.ORE.withConfiguration(new OreFeatureConfig(NATURAL_STONE, ModBlocks.dye_ore.getDefaultState(), 6)).withPlacement(COUNT_RANGE.configure(new CountRangeConfig(8, 5, 0, 16))));
                biome.addFeature(GenerationStage.Decoration.UNDERGROUND_ORES, Feature.ORE.withConfiguration(new OreFeatureConfig(NATURAL_STONE, ModBlocks.ender_pearl_ore.getDefaultState(), 4)).withPlacement(COUNT_RANGE.configure(new CountRangeConfig(3, 5, 0, 16))));

                //Nether Ores
                biome.addFeature(GenerationStage.Decoration.UNDERGROUND_ORES, Feature.ORE.withConfiguration(new OreFeatureConfig(NETHERRACK, ModBlocks.dye_ore_nether.getDefaultState(), 6)).withPlacement(COUNT_RANGE.configure(new CountRangeConfig(8, 5, 0, 16))));
                biome.addFeature(GenerationStage.Decoration.UNDERGROUND_ORES, Feature.ORE.withConfiguration(new OreFeatureConfig(NETHERRACK, ModBlocks.ender_pearl_ore_nether.getDefaultState(), 4)).withPlacement(COUNT_RANGE.configure(new CountRangeConfig(3, 5, 0, 16))));

                //End Ores
                //biome.addFeature(GenerationStage.Decoration.UNDERGROUND_ORES, END_OREGEN.withConfiguration(new OreFeatureConfig(NATURAL_STONE, ModBlocks.dye_ore_end.getDefaultState(), 6)).withPlacement(COUNT_RANGE.configure(new CountRangeConfig(8, 5, 0, 256))));
                //biome.addFeature(GenerationStage.Decoration.UNDERGROUND_ORES, END_OREGEN.withConfiguration(new OreFeatureConfig(NATURAL_STONE, ModBlocks.ender_pearl_ore_end.getDefaultState(), 4)).withPlacement(COUNT_RANGE.configure(new CountRangeConfig(3, 5, 0, 256))));
            }
        }
    }
}
