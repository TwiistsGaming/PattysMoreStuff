package com.stc.pattysmorestuff.world;

import com.mojang.serialization.Codec;
import com.stc.pattysmorestuff.blocks.BlockWildCrop;
import net.minecraft.block.BlockState;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.ISeedReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldWriter;
import net.minecraft.world.gen.ChunkGenerator;
import net.minecraft.world.gen.GenerationStage;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.NoFeatureConfig;
import net.minecraft.world.gen.feature.structure.StructureManager;

import java.util.Random;
import java.util.function.Function;

public class WildCropsGenFeature extends Feature<NoFeatureConfig> {


    public WildCropsGenFeature(Codec<NoFeatureConfig> p_i231953_1_) {
        super(p_i231953_1_);
    }

    @Override
    public boolean func_230362_a_(ISeedReader p_230362_1_, StructureManager p_230362_2_, ChunkGenerator p_230362_3_, Random p_230362_4_, BlockPos p_230362_5_, NoFeatureConfig p_230362_6_) {
        return false;
    }

    /*@Override
    public boolean place(IWorld world, ChunkGenerator<? extends GenerationStage> generator, Random random, BlockPos pos, NoFeatureConfig config) {

        if (random.nextInt(1000) != 0)
            return false;


        int place0 = (int) ((Math.random() * 4) + 1);
        int place1 = (int) ((Math.random() * 4) + 1);


        if (world.getBlockState(pos.north(place0).down()).getBlock().isIn(BlockTags.SMALL_FLOWERS) && world.getBlockState(pos.north(place0)).getMaterial().isReplaceable())
            BlockWildCrop.generateBush(world, pos.north(place0), random);
        if (world.getBlockState(pos.south(place1).down()).getBlock().isIn(BlockTags.SMALL_FLOWERS) && world.getBlockState(pos.south(place1)).getMaterial().isReplaceable())
            BlockWildCrop.generateBush(world, pos.south(place1), random);


        return true;
    }
    */
}
