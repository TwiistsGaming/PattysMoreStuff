package com.stc.pattysmorestuff.world;

import com.stc.pattysmorestuff.PattysMoreStuff;
import com.stc.pattysmorestuff.config.ConfigGeneral;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.NoFeatureConfig;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.IForgeRegistryEntry;

@Mod.EventBusSubscriber(modid = PattysMoreStuff.MODID)
public class WildCropsWorldGen {

    public static Feature<NoFeatureConfig> wild_crop;

    public static void registerAll(RegistryEvent.Register<Feature<?>> event) {
        if (!event.getName().equals(ForgeRegistries.FEATURES.getRegistryName())) return;
        IForgeRegistry<Feature<?>> r = event.getRegistry();

            wild_crop = register(r, new WildCropsGenFeature(NoFeatureConfig.field_236558_a_), "wild_crop");

    }
    private static <V extends R, R extends IForgeRegistryEntry<R>> V register(IForgeRegistry<R> registry, V value, String name)
    {
        ResourceLocation id = PattysMoreStuff.getId(name);
        value.setRegistryName(id);
        registry.register(value);
        return value;
    }
}
