package com.stc.pattysmorestuff.util;

import com.stc.pattysmorestuff.PattysMoreStuff;
import com.stc.pattysmorestuff.blocks.crusher.CrusherContainer;
import com.stc.pattysmorestuff.items.backpack.BackpackContainer;
import com.stc.pattysmorestuff.tileentity.crates.containers.CrateContainer;
import net.minecraft.inventory.container.ContainerType;
import net.minecraftforge.registries.ObjectHolder;

@ObjectHolder(PattysMoreStuff.MODID)
public class ContainerTypes {


    /*@ObjectHolder(ContainerNames.OAK_CRATE)
    public static ContainerType<CrateContainer> OAK_CRATE;
    @ObjectHolder(ContainerNames.SPRUCE_CRATE)
    public static ContainerType<CrateContainer> SPRUCE_CRATE;
    @ObjectHolder(ContainerNames.BIRCH_CRATE)
    public static ContainerType<CrateContainer> BIRCH_CRATE;
    @ObjectHolder(ContainerNames.JUNGLE_CRATE)
    public static ContainerType<CrateContainer> JUNGLE_CRATE;
    @ObjectHolder(ContainerNames.ACACIA_CRATE)
    public static ContainerType<CrateContainer> ACACIA_CRATE;
    @ObjectHolder(ContainerNames.BIG_OAK_CRATE)
    public static ContainerType<CrateContainer> BIG_OAK_CRATE;*/
    @ObjectHolder(ContainerNames.CRUSHER)
    public static ContainerType<CrusherContainer> CRUSHER;
    @ObjectHolder(ContainerNames.BACKPACK)
    public static ContainerType<BackpackContainer> BACKPACK;
    /*@ObjectHolder("crusher_gui")
    public static final ContainerType<CrusherContainer> CRUSHER = null;

    @Mod.EventBusSubscriber(modid = PattysMoreStuff.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static class Registration {
        @SubscribeEvent
        public static void onContainerTypeRegister(final RegistryEvent.Register<ContainerType<?>> event) {
            IForgeRegistry<ContainerType<?>> registry = event.getRegistry();

            registry.register(new ContainerType<CrusherContainer>(CrusherContainer::new).setRegistryName(PattysMoreStuff.getId("crusher_gui")));
        }
    }*/

}
