package com.stc.pattysmorestuff.util;

import com.stc.pattysmorestuff.PattysMoreStuff;

public class TileEntityNames {

    public static final String IRON_FURNACE = PattysMoreStuff.MODID + ":iron_furnace";
    public static final String GOLD_FURNACE = PattysMoreStuff.MODID + ":gold_furnace";
    public static final String DIAMOND_FURNACE = PattysMoreStuff.MODID + ":diamond_furnace";
    public static final String EMERALD_FURNACE = PattysMoreStuff.MODID + ":emerald_furnace";
    public static final String OBSIDIAN_FURNACE = PattysMoreStuff.MODID + ":obsidian_furnace";
    public static final String ULTIMATE_FURNACE = PattysMoreStuff.MODID + ":ultimate_furnace";

    public static final String OAK_CRATE = PattysMoreStuff.MODID + ":oak_storage_crate";
    public static final String SPRUCE_CRATE = PattysMoreStuff.MODID + ":spruce_storage_crate";
    public static final String BIRCH_CRATE = PattysMoreStuff.MODID + ":birch_storage_crate";
    public static final String JUNGLE_CRATE = PattysMoreStuff.MODID + ":jungle_storage_crate";
    public static final String ACACIA_CRATE = PattysMoreStuff.MODID + ":acacia_storage_crate";
    public static final String DARK_OAK_CRATE = PattysMoreStuff.MODID + ":big_oak_storage_crate";

    public static final String CRUSHER = PattysMoreStuff.MODID + ":crusher";
    public static final String IRON_CRUSHER = PattysMoreStuff.MODID + ":iron_crusher";
    public static final String GOLD_CRUSHER = PattysMoreStuff.MODID + ":gold_crusher";
    public static final String DIAMOND_CRUSHER = PattysMoreStuff.MODID + ":diamond_crusher";
    public static final String EMERALD_CRUSHER = PattysMoreStuff.MODID + ":emerald_crusher";
    public static final String OBSIDIAN_CRUSHER = PattysMoreStuff.MODID + ":obsidian_crusher";
    public static final String ULTIMATE_CRUSHER = PattysMoreStuff.MODID + ":ultimate_crusher";

    public static final String RED_JAR = PattysMoreStuff.MODID + ":cookie_jar_red";
}
