package com.stc.pattysmorestuff.util;

import com.stc.pattysmorestuff.PattysMoreStuff;

public class ContainerNames {

    /*public static final String OAK_CRATE = PattysMoreStuff.MODID + ":oak_storage_crate";
    public static final String SPRUCE_CRATE = PattysMoreStuff.MODID + ":spruce_storage_crate";
    public static final String BIRCH_CRATE = PattysMoreStuff.MODID + ":birch_storage_crate";
    public static final String JUNGLE_CRATE = PattysMoreStuff.MODID + ":jungle_storage_crate";
    public static final String ACACIA_CRATE = PattysMoreStuff.MODID + ":acacia_storage_crate";
    public static final String BIG_OAK_CRATE = PattysMoreStuff.MODID + ":big_oak_storage_crate";*/
    public static final String CRUSHER = PattysMoreStuff.MODID + ":crusher";
    public static final String BACKPACK = PattysMoreStuff.MODID + ":backpack";

}
