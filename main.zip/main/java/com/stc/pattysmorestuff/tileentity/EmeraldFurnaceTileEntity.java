package com.stc.pattysmorestuff.tileentity;

import com.stc.pattysmorestuff.handlers.RegisteryHandler;
import com.stc.pattysmorestuff.init.ModTileEntities;
import com.stc.pattysmorestuff.tileentity.abstracts.AbstractEmeraldFurnaceTileEntity;
import com.stc.pattysmorestuff.util.FurnaceType;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.container.Container;
import net.minecraft.inventory.container.FurnaceContainer;
import net.minecraft.item.crafting.IRecipeType;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TranslationTextComponent;

public class EmeraldFurnaceTileEntity extends AbstractEmeraldFurnaceTileEntity {

    public EmeraldFurnaceTileEntity() {
        super(ModTileEntities.EMERALD_FURNACE_TE, IRecipeType.SMELTING, FurnaceType.EMERALD_FURNACE.cookSpeed, FurnaceType.EMERALD_FURNACE.output);
    }

    protected ITextComponent getDefaultName() {
        return new TranslationTextComponent("Emerald Furnace");
    }

    protected Container createMenu(int id, PlayerInventory player) {
        return new FurnaceContainer(id, player, this, this.furnaceData);
    }
}
