package com.stc.pattysmorestuff.tileentity.crates.containers;

import net.minecraft.inventory.container.ContainerType;
import net.minecraftforge.registries.ObjectHolder;

public class CrateContainerType {

    /*@ObjectHolder(ContainerNames.OAK_CRATE)
    public static ContainerType<CrateContainer> OAK_CRATE;
    @ObjectHolder(ContainerNames.SPRUCE_CRATE)
    public static ContainerType<CrateContainer> SPRUCE_CRATE;
    @ObjectHolder(ContainerNames.BIRCH_CRATE)
    public static ContainerType<CrateContainer> BIRCH_CRATE;
    @ObjectHolder(ContainerNames.JUNGLE_CRATE)
    public static ContainerType<CrateContainer> JUNGLE_CRATE;
    @ObjectHolder(ContainerNames.ACACIA_CRATE)
    public static ContainerType<CrateContainer> ACACIA_CRATE;
    @ObjectHolder(ContainerNames.BIG_OAK_CRATE)
    public static ContainerType<CrateContainer> BIG_OAK_CRATE;*/
}
