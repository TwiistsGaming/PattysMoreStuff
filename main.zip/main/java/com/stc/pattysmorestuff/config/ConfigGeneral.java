package com.stc.pattysmorestuff.config;

import com.electronwill.nightconfig.core.file.CommentedFileConfig;
import com.electronwill.nightconfig.core.io.WritingMode;
import com.stc.pattysmorestuff.PattysMoreStuff;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.fml.common.Mod;

import java.io.File;

@Mod.EventBusSubscriber
public class ConfigGeneral {
    public static final ForgeConfigSpec CLIENT_CONFIG;
    private static final ForgeConfigSpec.Builder CLIENT_BUILDER = new ForgeConfigSpec.Builder();

    public static ForgeConfigSpec.BooleanValue disableArmor;
    public static ForgeConfigSpec.BooleanValue disableTools;
    public static ForgeConfigSpec.BooleanValue disableFood;
    public static ForgeConfigSpec.BooleanValue disableDrinks;
    public static ForgeConfigSpec.BooleanValue disableBlocks;
    public static ForgeConfigSpec.BooleanValue disableOres;
    public static ForgeConfigSpec.BooleanValue disableFurnaces;
    public static ForgeConfigSpec.BooleanValue disableCrushers;
    public static ForgeConfigSpec.BooleanValue disableBows;
    public static ForgeConfigSpec.BooleanValue disableHammers;
    public static ForgeConfigSpec.BooleanValue disableScythes;
    public static ForgeConfigSpec.BooleanValue disableExcavator;
    public static ForgeConfigSpec.BooleanValue disablePaxel;
    public static ForgeConfigSpec.BooleanValue disableLumberAxe;
    public static ForgeConfigSpec.BooleanValue disableFlightRing;
    public static ForgeConfigSpec.BooleanValue disableTimeWand;
    public static ForgeConfigSpec.BooleanValue disableWeatherWand;
    public static ForgeConfigSpec.BooleanValue disableMagnet;
    public static ForgeConfigSpec.BooleanValue disableWrench;
    public static ForgeConfigSpec.BooleanValue disableIlluminationWand;
    public static ForgeConfigSpec.BooleanValue disableInfiniteWaterBucket;
    public static ForgeConfigSpec.BooleanValue disableInfiniteLavaBucket;
    public static ForgeConfigSpec.BooleanValue disableWildCrop;
    public static ForgeConfigSpec.IntValue wildCropChance;

    static {
        init(CLIENT_BUILDER);

        CLIENT_CONFIG = CLIENT_BUILDER.build();
    }

    public static void init( ForgeConfigSpec.Builder client) {

        client.comment("Enable or disable armor sets").push("Armor");
        disableArmor = client
                .comment("Setting this to false will disable all the armor [true /false default: true]")
                .define("EnableArmor", true);
        client.pop();
        client.comment("Enable or disable tools").push("Tools");
        disableTools = client
                .comment("Setting this to false will disable all the tools [true /false default: true]")
                .define("EnableTools", true);
        client.pop();
        client.comment("Enable or disable Food").push("Food");
        disableFood = client
                .comment("Setting this to false will disable all the Food [true /false default: true]")
                .define("EnableFood", true);
        client.pop();
        client.comment("Enable or disable Drinks").push("Drinks");
        disableDrinks = client
                .comment("Setting this to false will disable all the drinks [true /false default: true]")
                .define("EnableDrinks", true);
        client.pop();
        client.comment("Enable or disable Blocks").push("Blocks");
        disableBlocks = client
                .comment("Setting this to false will disable all the blocks [true /false default: true]")
                .define("EnableBlocks", true);
        client.pop();
        client.comment("Enable or disable Ores").push("Ores");
        disableOres = client
                .comment("Setting this to false will disable all the ores [true /false default: true]")
                .define("EnableOres", true);
        client.pop();
        client.comment("Enable or disable Wild Crop").push("WildCrop");
        disableWildCrop = client
                .comment("Setting this to false will disable the wild crop [true /false default: true]")
                .define("EnableWildCrop", true);
        wildCropChance = client
                .comment("Chance of wild crops generating in the Overworld. Higher numbers mean a higher change to spawn per chunk chance [default: 64]")
                .defineInRange("Chance of Wild Crops spawning", 64, 0, 1000000000);
        client.pop();
        client.comment("Enable or disable Furnaces").push("Furnaces");
        disableFurnaces = client
                .comment("Setting this to false will disable all the furnaces [true /false default: true]")
                .define("EnableFurnaces", true);
        client.pop();
        client.comment("Enable or disable Crushers").push("Crushers");
        disableCrushers = client
                .comment("Setting this to false will disable all the crushers [true /false default: true]")
                .define("EnableCrushers", true);
        client.pop();
        client.comment("Enable or disable Bows").push("Bows");
        disableBows = client
                .comment("Setting this to false will disable all the bows [true /false default: true]")
                .define("EnableBows", true);
        client.pop();
        client.comment("Enable or disable Hammers").push("Hammers");
        disableHammers = client
                .comment("Setting this to false will disable all the hammers [true /false default: true]")
                .define("EnableHammers", true);
        client.pop();
        client.comment("Enable or disable Scythes").push("Scythes");
        disableScythes = client
                .comment("Setting this to false will disable all the scythes [true /false default: true]")
                .define("EnableScythes", true);
        client.pop();
        client.comment("Enable or disable Excavator").push("Excavator");
        disableExcavator = client
                .comment("Setting this to false will disable all the excavators [true /false default: true]")
                .define("EnableExcavator", true);
        client.pop();
        client.comment("Enable or disable Paxel").push("Paxel");
        disablePaxel = client
                .comment("Setting this to false will disable all the paxels [true /false default: true]")
                .define("EnablePaxel", true);
        client.pop();
        client.comment("Enable or disable Lumber Axe").push("LumberAxes");
        disableLumberAxe = client
                .comment("Setting this to false will disable all the lumber axes [true /false default: true]")
                .define("EnableLumberAxe", true);
        client.pop();
        client.comment("Enable or disable Ring of Flight").push("RingOfFlight");
        disableFlightRing = client
                .comment("Setting this to false will disable the ring of flight [true /false default: true]")
                .define("EnableRingOfFlight", true);
        client.pop();
        client.comment("Enable or disable Infinite Buckets").push("InfiniteBuckets");
        disableInfiniteWaterBucket = client
                .comment("Setting this to false will disable the infinite water buckets [true /false default: true]")
                .define("EnableInfiniteWaterBucket", true);
        client.pop();
        client.comment("Enable or disable Infinite Buckets").push("InfiniteBuckets");
        disableInfiniteLavaBucket = client
                .comment("Setting this to true will enable the infinite lava bucket [true /false default: false]")
                .define("EnableInfiniteLavaBucket", false);
        client.pop();
        client.comment("Enable or disable Wands").push("Wands");
        disableTimeWand = client
                .comment("Setting this to false will disable the time wand [true /false default: true]")
                .comment("CURRENTLY NOT WORKING")
                .define("EnableTimeWand", false);
        client.pop();
        client.comment("Enable or disable Wands").push("Wands");
        disableWeatherWand = client
                .comment("Setting this to false will disable the weather wand [true /false default: true]")
                .comment("CURRENTLY NOT WORKING")
                .define("EnableWeatherWand", false);
        client.pop();
        client.comment("Enable or disable Wands").push("Wands");
        disableIlluminationWand = client
                .comment("Setting this to false will disable the illumination wand [true /false default: true]")
                .define("EnableIlluminationWand", true);
        client.pop();
        client.comment("Enable or disable Wrench").push("Wrench");
        disableWrench = client
                .comment("Setting this to false will disable the wrench [true /false default: true]")
                .define("EnableWrench", true);
        client.pop();
        client.comment("Enable or disable Magnet").push("Magnet");
        disableMagnet = client
                .comment("Setting this to false will disable the magnet [true /false default: true]")
                .define("EnableMagnet", true);
        client.pop();

    }

    public static void loadConfig(ForgeConfigSpec spec, String path) {
        PattysMoreStuff.LOGGER.info("Loading config: " + path);
        final CommentedFileConfig file = CommentedFileConfig.builder(new File(path)).sync().autosave().writingMode(WritingMode.REPLACE).build();
        PattysMoreStuff.LOGGER.info("Built config: " + path);
        file.load();
        PattysMoreStuff.LOGGER.info("Loaded config: " + path);
        spec.setConfig(file);
    }
}
