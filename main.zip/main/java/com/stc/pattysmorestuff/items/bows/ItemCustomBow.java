package com.stc.pattysmorestuff.items.bows;

import com.stc.pattysmorestuff.PattysMoreStuff;
import com.stc.pattysmorestuff.config.ConfigGeneral;
import com.stc.pattysmorestuff.init.ModItems;
import net.minecraft.item.BowItem;
import net.minecraft.item.ItemStack;

public class ItemCustomBow extends BowItem {
    public ItemCustomBow(String name, Properties properties) {
        super(properties);
        this.setRegistryName(PattysMoreStuff.MODID, name);

        if(ConfigGeneral.disableBows.get()) {
            ModItems.ITEMS.add(this);
        }
    }

    @Override
    public boolean hasEffect(ItemStack stack) {
        if(stack.getItem() == ModItems.nstar_bow) {
            return true;
        }
        return false;
    }
}
