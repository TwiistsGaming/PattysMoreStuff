package com.stc.pattysmorestuff.items;

import com.stc.pattysmorestuff.PattysMoreStuff;
import com.stc.pattysmorestuff.config.ConfigGeneral;
import com.stc.pattysmorestuff.init.ModItems;
import net.minecraft.item.Item;

public class ItemFlightRing extends Item {

    public ItemFlightRing(String name, Properties properties) {
        super(properties.maxStackSize(1));
        this.setRegistryName(PattysMoreStuff.MODID, name);

        if(ConfigGeneral.disableFlightRing.get()) {

            ModItems.ITEMS.add(this);
        }
    }
}
