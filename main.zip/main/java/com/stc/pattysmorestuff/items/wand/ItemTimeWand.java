package com.stc.pattysmorestuff.items.wand;

import com.stc.pattysmorestuff.PattysMoreStuff;
import com.stc.pattysmorestuff.config.ConfigGeneral;
import com.stc.pattysmorestuff.init.ModItems;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.List;


public class ItemTimeWand extends Item {
    public ItemTimeWand(String name, Properties properties) {
        super(properties.maxStackSize(1).maxDamage(136).setNoRepair());
        this.setRegistryName(PattysMoreStuff.MODID, name);

        if(ConfigGeneral.disableTimeWand.get()) {
            ModItems.ITEMS.add(this);
        }

    }

    @Override
    public void addInformation(ItemStack stack, @Nullable World worldIn, List<ITextComponent> tooltip, ITooltipFlag flagIn) {
        tooltip.add(new StringTextComponent(TextFormatting.GREEN + "Switchs from night to day and from day to night!"));
    }
}
