package com.stc.pattysmorestuff.items.wand;

import com.stc.pattysmorestuff.PattysMoreStuff;
import com.stc.pattysmorestuff.config.ConfigGeneral;
import com.stc.pattysmorestuff.init.ModItems;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.List;

public class ItemWeatherWand extends Item {
    public ItemWeatherWand(String name, Properties properties) {
        super(properties.maxStackSize(1).maxDamage(136).setNoRepair());
        this.setRegistryName(PattysMoreStuff.MODID, name);

        if(ConfigGeneral.disableWeatherWand.get()) {
            ModItems.ITEMS.add(this);
        }
    }

    @Override
    public void addInformation(ItemStack stack, @Nullable World worldIn, List<ITextComponent> tooltip, ITooltipFlag flagIn) {
        tooltip.add(new StringTextComponent(TextFormatting.GREEN + "Currently only clears rain/thunder storms and makes it sunny!"));
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World worldIn, PlayerEntity playerIn, Hand handIn) {
        if (worldIn.isThundering() || worldIn.isRaining()) {
            worldIn.setRainStrength(0);
            worldIn.setThunderStrength(0);
            worldIn.getWorldInfo().setRaining(false);
            //worldIn.getWorldInfo().isThundering();
        }

        return super.onItemRightClick(worldIn, playerIn, handIn);
    }
}
