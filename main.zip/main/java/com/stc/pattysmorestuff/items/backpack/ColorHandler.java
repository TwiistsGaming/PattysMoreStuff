package com.stc.pattysmorestuff.items.backpack;

import com.stc.pattysmorestuff.init.ModItems;
import net.minecraftforge.client.event.ColorHandlerEvent;

public class ColorHandler {

    public static void registerItemColors(ColorHandlerEvent.Item event) {
        //event.getItemColors().register(ItemBackpack::getItemColor, ModItems.backpack);
    }
}
