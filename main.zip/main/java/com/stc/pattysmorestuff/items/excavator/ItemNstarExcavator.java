package com.stc.pattysmorestuff.items.excavator;

import com.stc.pattysmorestuff.PattysMoreStuff;
import com.stc.pattysmorestuff.config.ConfigGeneral;
import com.stc.pattysmorestuff.init.ModItems;
import com.stc.pattysmorestuff.items.tools.PMTTool;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceContext;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import net.minecraftforge.common.ToolType;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.List;

public class ItemNstarExcavator extends ShovelItem implements PMTTool {

    public ItemNstarExcavator(String name, IItemTier tier, int attackDamageIn, float attackSpeedIn, Item.Properties builder) {
        super(tier, attackDamageIn, attackSpeedIn, builder);

        this.setRegistryName(PattysMoreStuff.MODID, name);
        if(ConfigGeneral.disableExcavator.get()) {

            ModItems.ITEMS.add(this);
        }
    }

    @Nonnull
    @Override
    public ToolType getPMTToolClass() {
        return ToolType.SHOVEL;
    }

    @Nullable
    @Override
    public RayTraceResult rayTraceBlocks(World world, PlayerEntity player) {
        return rayTrace(world, player, RayTraceContext.FluidMode.NONE);
    }


    @Override
    public boolean onBlockStartBreak(ItemStack itemstack, BlockPos pos, PlayerEntity player) {
        //return PMTTool.BreakHandler.onBlockStartBreak(itemstack, pos, player);
        return false;
    }

    @Override
    public void addInformation(ItemStack stack, @Nullable World worldIn, List<ITextComponent> tooltip, ITooltipFlag flagIn) {
        tooltip.add(new StringTextComponent(TextFormatting.YELLOW  + "Excavator that mines in a 3x3x1 from the block you mine"));
    }

    @Override
    public boolean hasEffect(ItemStack stack) {
        return true;
    }
}
