package com.stc.pattysmorestuff.items;

import net.minecraft.block.BlockState;

public interface IBreakValidator {

    boolean canBreak(BlockState state);

}
