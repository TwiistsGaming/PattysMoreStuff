package com.stc.pattysmorestuff.items.tools;

import com.stc.pattysmorestuff.PattysMoreStuff;
import com.stc.pattysmorestuff.config.ConfigGeneral;
import com.stc.pattysmorestuff.init.ModItems;
import net.minecraft.item.HoeItem;
import net.minecraft.item.IItemTier;
import net.minecraft.item.ItemStack;

public class ItemCustomHoe extends HoeItem {
    public ItemCustomHoe(String name, IItemTier tier, int p_i231595_2_, float attackSpeedIn, Properties builder) {
        super(tier, p_i231595_2_, attackSpeedIn, builder);
        this.setRegistryName(PattysMoreStuff.MODID, name);
        if(ConfigGeneral.disableTools.get()) {

            ModItems.ITEMS.add(this);
        }
    }

    @Override
    public boolean getIsRepairable(ItemStack toRepair, ItemStack repair) {
        return true;
    }

    @Override
    public boolean hasEffect(ItemStack stack) {
        if(stack.getItem() == ModItems.nstar_hoe) {
            return true;
        }

        return false;
    }
}
