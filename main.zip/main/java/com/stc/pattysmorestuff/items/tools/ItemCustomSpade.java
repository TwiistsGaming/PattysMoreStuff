package com.stc.pattysmorestuff.items.tools;

import com.stc.pattysmorestuff.PattysMoreStuff;
import com.stc.pattysmorestuff.config.ConfigGeneral;
import com.stc.pattysmorestuff.init.ModItems;
import net.minecraft.item.IItemTier;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ShovelItem;

public class ItemCustomSpade extends ShovelItem {
    public ItemCustomSpade(String name, IItemTier tier, float attackDamageIn, float attackSpeedIn, Properties builder) {
        super(tier, attackDamageIn, attackSpeedIn, builder);
        this.setRegistryName(PattysMoreStuff.MODID, name);

        if(ConfigGeneral.disableTools.get()) {

            ModItems.ITEMS.add(this);
        }
    }

    @Override
    public boolean getIsRepairable(ItemStack toRepair, ItemStack repair) {
        return true;
    }

    @Override
    public boolean hasEffect(ItemStack stack) {
        if(stack.getItem() == ModItems.nstar_shovel) {
            return true;
        }

        return false;
    }
}
