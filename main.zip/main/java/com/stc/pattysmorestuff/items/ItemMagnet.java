package com.stc.pattysmorestuff.items;

import com.stc.pattysmorestuff.PattysMoreStuff;
import com.stc.pattysmorestuff.config.ConfigGeneral;
import com.stc.pattysmorestuff.init.ModItems;
import com.stc.pattysmorestuff.util.EnableUtil;
import com.stc.pattysmorestuff.util.MagnetRange;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.ExperienceOrbEntity;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUseContext;
import net.minecraft.util.ActionResult;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Hand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;

import java.util.List;

public class ItemMagnet extends Item {
    public ItemMagnet(String name, Properties properties) {
        super(properties);
        this.setRegistryName(PattysMoreStuff.MODID, name);

        if(ConfigGeneral.disableMagnet.get()) {
            ModItems.ITEMS.add(this);
        }
    }

    private boolean enabled = EnableUtil.isEnabled(new ItemStack(this));

    @Override
    public boolean hasEffect(ItemStack p_77636_1_) {
        return EnableUtil.isEnabled(p_77636_1_);
    }

    int range;

    public void inventoryTick(ItemStack stack, World world, Entity entity, int itemSlot, boolean isSelected)
    {
        if(entity instanceof PlayerEntity && !world.isRemote && EnableUtil.isEnabled(stack))
        {
            PlayerEntity player = (PlayerEntity)entity;

            boolean init = MagnetRange.getCurrentlySet(stack);

            if(!init)
            {
                range = 0;
            }
            else
            {
                range = MagnetRange.getCurrentRange(stack);
            }

            double x = player.prevPosX;
            double y = player.prevPosY + 1.5;
            double z = player.prevPosZ;

            boolean isPulling;

            //Scan for and collect items
            List<ItemEntity> items = entity.world.getEntitiesWithinAABB(ItemEntity.class, new AxisAlignedBB(x - range, y - range, z - range, x + range, y + range, z + range));
            for(ItemEntity e: items)
            {
                if(!player.isCrouching() && !e.getPersistentData().getBoolean("PreventRemoteMovement"))
                {
                    isPulling = true;
                    double factor = 0.02;
                    e.addVelocity((x - e.prevPosX) * factor, (y - e.prevPosY) * factor, (z - e.prevPosZ) * factor);
                }
            }

            if(items.isEmpty())
            {
                isPulling = false;
            }

            //Scan for and collect XP Orbs
            List<ExperienceOrbEntity> xp = entity.world.getEntitiesWithinAABB(ExperienceOrbEntity.class, new AxisAlignedBB(x - range, y - range, z - range, x + range, y + range, z + range));
            for(ExperienceOrbEntity orb: xp)
            {
                if(!player.isCrouching())
                {
                    isPulling = true;
                    double factor = 0.02;
                    orb.addVelocity((x - orb.prevPosX) * factor, (y - orb.prevPosY) * factor, (z - orb.prevPosZ) * factor);
                    player.onItemPickup(orb, 1);
                    player.giveExperiencePoints(orb.xpValue);
                    orb.remove();
                }
            }

            if(items.isEmpty())
            {
                isPulling = false;
            }
        }
    }

    @Override
    public ActionResultType onItemUse(ItemUseContext context) {
        if(!context.getWorld().isRemote)
        {
            if(this.enabled == true)
            {
                this.enabled = false;
            }
            else
            {
                this.enabled = true;
            }
        }
        return ActionResultType.SUCCESS;
    }


    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, PlayerEntity player, Hand hand)
    {
        ItemStack stack = player.getHeldItem(hand);

        if(!world.isRemote && (player.isCrouching()))
        {
            EnableUtil.changeEnabled(player, hand);
            //player.sendMessage(new StringTextComponent("Attraction ability active: " + EnableUtil.isEnabled(stack)));
            MagnetRange.setCurrentRange(stack, 8);
            return new ActionResult<ItemStack>(ActionResultType.SUCCESS, player.getHeldItem(hand));
        }

        return super.onItemRightClick(world, player, hand);
    }

    @Override
    public void addInformation(ItemStack stack, World world, List<ITextComponent> list, ITooltipFlag flag)
    {
        super.addInformation(stack, world, list, flag);
        list.add(new StringTextComponent(TextFormatting.BLUE + "Draws dropped items from 8 blocks away toward the player"));
        list.add(new StringTextComponent(TextFormatting.RED + "Attraction ability active: " + EnableUtil.isEnabled(stack)));
        list.add(new StringTextComponent(TextFormatting.GOLD + "Works while in player inventory"));
        list.add(new StringTextComponent(TextFormatting.GREEN + "Right-click to toggle on/off"));
    }
}
