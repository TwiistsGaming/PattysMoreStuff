package com.stc.pattysmorestuff.items.drinks;

import com.stc.pattysmorestuff.config.ConfigGeneral;
import com.stc.pattysmorestuff.init.ModItems;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.*;
import net.minecraft.stats.Stats;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.List;

public class ItemDrinkable extends Item {

    public ItemDrinkable(String name, Properties properties) {
        super(properties);
        this.setRegistryName(name);

        if(ConfigGeneral.disableDrinks.get()) {

            ModItems.ITEMS.add(this);
        }

    }

    public ActionResult<ItemStack> onItemRightClick(World worldIn, PlayerEntity playerIn, Hand handIn) {
        playerIn.setActiveHand(handIn);
        return ActionResult.resultPass(playerIn.getHeldItem(handIn));
    }

    @Override
    public void addInformation(ItemStack stack, @Nullable World worldIn, List<ITextComponent> tooltip, ITooltipFlag flagIn) {
        if(stack.getItem() == ModItems.carrot_juice) {
            tooltip.add(new StringTextComponent("\u00A7cRight click a carrot on the blender to obtain this juice"));
        }
        if(stack.getItem() == ModItems.melon_juice) {
            tooltip.add(new StringTextComponent("\u00A7cRight click a melon on the blender to obtain this juice"));
        }
        if(stack.getItem() == ModItems.beetroot_juice) {
            tooltip.add(new StringTextComponent("\u00A7cRight click a beetroot on the blender to obtain this juice"));
        }
        if(stack.getItem() == ModItems.pumpkin_juice) {
            tooltip.add(new StringTextComponent("\u00A7cRight click a pumpkin on the blender to obtain this juice"));
        }
        if(stack.getItem() == ModItems.apple_juice) {
            tooltip.add(new StringTextComponent("\u00A7cRight click a apple on the blender to obtain this juice"));
        }
    }

    @Override
    public UseAction getUseAction(ItemStack stack) {
        return UseAction.DRINK;
    }

    public int getUseDuration(ItemStack stack) {
        return 32;

    }

    public ItemStack onItemUseFinish(ItemStack stack, World worldIn, LivingEntity entityLiving) {
        PlayerEntity playerentity = entityLiving instanceof PlayerEntity ? (PlayerEntity)entityLiving : null;
        if (playerentity instanceof ServerPlayerEntity) {
            CriteriaTriggers.CONSUME_ITEM.trigger((ServerPlayerEntity)playerentity, stack);
        }

        if (playerentity != null) {
            playerentity.addStat(Stats.ITEM_USED.get(this));
            if (!playerentity.abilities.isCreativeMode) {
                stack.shrink(1);
            }
        }

        if (playerentity == null || !playerentity.abilities.isCreativeMode) {
            if (stack.isEmpty()) {
                return new ItemStack(Items.GLASS_BOTTLE);
            }

            if (playerentity != null) {
                playerentity.inventory.addItemStackToInventory(new ItemStack(Items.GLASS_BOTTLE));
            }
        }

        return stack;
    }
}
