package com.stc.pattysmorestuff.items;

import com.stc.pattysmorestuff.PattysMoreStuff;
import com.stc.pattysmorestuff.init.ModItems;
import net.minecraft.item.Item;

public class ItemBase extends Item {
    public ItemBase(String name, Properties properties) {
        super(properties);
        this.setRegistryName(PattysMoreStuff.MODID, name);

        ModItems.ITEMS.add(this);
    }
}
