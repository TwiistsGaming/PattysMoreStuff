package com.stc.pattysmorestuff.items.foods;

import com.stc.pattysmorestuff.PattysMoreStuff;
import com.stc.pattysmorestuff.config.ConfigGeneral;
import com.stc.pattysmorestuff.init.ModItems;
import net.minecraft.item.Item;

public class ItemCustomFood extends Item {
    public ItemCustomFood(String name, Properties properties) {
        super(properties);
        this.setRegistryName(PattysMoreStuff.MODID, name);

        if(ConfigGeneral.disableFood.get()) {

            ModItems.ITEMS.add(this);
        }
    }


}
