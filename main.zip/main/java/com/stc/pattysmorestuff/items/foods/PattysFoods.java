package com.stc.pattysmorestuff.items.foods;

import net.minecraft.item.Food;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;

public class PattysFoods {

    public static final Food FRIED_EGG = (new Food.Builder()).hunger(4).saturation(0.4F).build();
    public static final Food BACON_EGG = (new Food.Builder()).hunger(6).saturation(0.6F).build();
    public static final Food BACON_RAW = (new Food.Builder()).hunger(3).saturation(0.3F).build();
    public static final Food BACON_COOKED = (new Food.Builder()).hunger(7).saturation(0.7F).build();
    public static final Food SAUSAGE_RAW = (new Food.Builder()).hunger(3).saturation(0.3F).build();
    public static final Food SAUSAGE_COOKED = (new Food.Builder()).hunger(7).saturation(0.7F).build();
    public static final Food BAGUETTE_ROLL = (new Food.Builder()).hunger(5).saturation(0.7F).build();
    public static final Food BAGUETTE_BACON = (new Food.Builder()).hunger(8).saturation(0.8F).build();
    public static final Food BAGUETTE_EGG = (new Food.Builder()).hunger(6).saturation(0.7F).build();
    public static final Food BAGUETTE_EGGBACON = (new Food.Builder()).hunger(9).saturation(1.0F).build();
    public static final Food BAGUETTE_SAUSAGE = (new Food.Builder()).hunger(8).saturation(0.8F).build();
    public static final Food BAGUETTE_BACONSAUSAGE = (new Food.Builder()).hunger(8).saturation(0.8F).build();
    public static final Food BAGUETTE_EGGSAUSAGE = (new Food.Builder()).hunger(6).saturation(0.7F).build();
    public static final Food BAGUETTE_EGGBACONSAUSAGE = (new Food.Builder()).hunger(9).saturation(1.0F).build();
    public static final Food APPLE_PIE = (new Food.Builder()).hunger(8).saturation(0.3F).build();
    public static final Food SWEET_BERRIE_PIE = (new Food.Builder()).hunger(8).saturation(0.3F).build();
    public static final Food TOAST = (new Food.Builder()).hunger(7).saturation(1.2F).build();
    public static final Food FRUIT_SALAD = (new Food.Builder()).hunger(6).saturation(1.6F).build();
    public static final Food DOUBLE_CHOC_COOKIE = (new Food.Builder()).hunger(2).saturation(0.1F).build();

    public static final Food APPLE_JUICE = (new Food.Builder()).hunger(4).saturation(0.3F).build();
    public static final Food MELON_JUICE = (new Food.Builder()).hunger(2).saturation(0.3F).build();
    public static final Food CARROT_JUICE = (new Food.Builder()).hunger(3).saturation(0.6F).build();
    public static final Food BEETROOT_JUICE = (new Food.Builder()).hunger(1).saturation(0.6F).build();
    public static final Food PUMPKIN_JUICE = (new Food.Builder()).hunger(5).saturation(0.3F).build();
    public static final Food MILK_BOTTLE = (new Food.Builder()).hunger(1).saturation(0.6F).build();
    public static final Food CHOCOLATE_MILK_BOTTLE = (new Food.Builder()).hunger(1).saturation(0.6F).build();

    public static final Food APPLE_SLUSHIE = (new Food.Builder()).hunger(4).saturation(0.3F).build();
    public static final Food MELON_SLUSHIE = (new Food.Builder()).hunger(2).saturation(0.3F).build();
    public static final Food CARROT_SLUSHIE = (new Food.Builder()).hunger(3).saturation(0.6F).build();
    public static final Food BEETROOT_SLUSHIE = (new Food.Builder()).hunger(1).saturation(0.6F).build();
    public static final Food PUMPKIN_SLUSHIE = (new Food.Builder()).hunger(5).saturation(0.3F).build();

    public static final Food APPLE_SMOOTHIE = (new Food.Builder()).hunger(4).saturation(0.3F).build();
    public static final Food MELON_SMOOTHIE = (new Food.Builder()).hunger(2).saturation(0.3F).build();
    public static final Food CARROT_SMOOTHIE = (new Food.Builder()).hunger(3).saturation(0.6F).build();
    public static final Food BEETROOT_SMOOTHIE = (new Food.Builder()).hunger(1).saturation(0.6F).build();
    public static final Food PUMPKIN_SMOOTHIE = (new Food.Builder()).hunger(5).saturation(0.3F).build();

}
