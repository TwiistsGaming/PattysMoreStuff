package com.stc.pattysmorestuff;

import com.stc.pattysmorestuff.blocks.crusher.PMSCrusher;
import com.stc.pattysmorestuff.config.ConfigGeneral;
import com.stc.pattysmorestuff.handlers.PlayerTickEvent;
import com.stc.pattysmorestuff.handlers.RenderLook;
import com.stc.pattysmorestuff.init.ModScreens;
import com.stc.pattysmorestuff.init.ModTabs;
import com.stc.pattysmorestuff.network.ClientProxy;
import com.stc.pattysmorestuff.network.IProxy;
import com.stc.pattysmorestuff.network.ServerProxy;
import com.stc.pattysmorestuff.world.OreGenerator;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.loading.FMLPaths;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(value = PattysMoreStuff.MODID)
public class PattysMoreStuff
{

    public static final String MODID = "pattysmorestuff";
    public static  PattysMoreStuff instance;
    public static final Logger LOGGER = LogManager.getLogger(MODID);

    public static IProxy PROXY;

    public PattysMoreStuff() {
        instance = this;
        PROXY = DistExecutor.runForDist(() -> () -> new ClientProxy(), () -> () -> new ServerProxy());

        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, ConfigGeneral.CLIENT_CONFIG);

        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::preInit);
        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::init);
        //FMLJavaModLoadingContext.get().getModEventBus().addListener(ColorHandler::registerItemColors);

        ConfigGeneral.loadConfig(ConfigGeneral.CLIENT_CONFIG, FMLPaths.CONFIGDIR.get().resolve("pattysmorestuff-client.toml").toString());

        MinecraftForge.EVENT_BUS.register(this);
        //HoeEvent.init();
        if (ConfigGeneral.disableFlightRing.get()) {

            MinecraftForge.EVENT_BUS.register(PlayerTickEvent.class);
        }

        ModTabs.pattysTabs();
        PMSCrusher.setup();
        //ModRecipes.init();

    }



    private void preInit(final FMLCommonSetupEvent event)
    {
        OreGenerator.setupOreGen();


    }
    private void init(final FMLClientSetupEvent event){

        ModScreens.init();
        RenderLook.init();
    }

    public static ResourceLocation getId(String path) {
        return new ResourceLocation(MODID, path);
    }

}
