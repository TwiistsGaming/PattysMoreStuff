package com.stc.pattysmorestuff.blocks.jar;

import com.mojang.blaze3d.matrix.MatrixStack;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.model.ItemCameraTransforms;
import net.minecraft.client.renderer.tileentity.TileEntityRenderer;
import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.NonNullList;
import org.lwjgl.opengl.GL11;

import static net.minecraft.client.renderer.model.ItemCameraTransforms.TransformType.FIXED;
import static net.minecraft.client.renderer.model.ItemCameraTransforms.TransformType.NONE;

/*public class RenderJarRed extends TileEntityRenderer<TileEntityRedJar> {

    private final NonNullList<ItemStack> cookie = NonNullList.withSize(8, ItemStack.EMPTY);

    public RenderJarRed(TileEntityRendererDispatcher dispatcher) {
        super(dispatcher);
    }


    @Override
    public boolean isGlobalRenderer(TileEntityRedJar te) {
        return false;
    }



    @Override
    public void render(TileEntityRedJar tileEntityIn, float partialTicks, MatrixStack matrixStackIn, IRenderTypeBuffer bufferIn, int combinedLightIn, int combinedOverlayIn) {


            matrixStackIn.push();

            //matrixStackIn.translate(0.5,0.05,0.18);
            matrixStackIn.rotate(Vector3f.XP.rotation(130));
            matrixStackIn.translate(0, 0, 0);
            matrixStackIn.scale(0.375F, 0.375F, 0.375F);

            for(int i = 0; i < tileEntityIn.cookieCount; i++) {
            Minecraft.getInstance().getItemRenderer().renderItem(new ItemStack(Items.COOKIE), FIXED, combinedLightIn, combinedOverlayIn, matrixStackIn, bufferIn);
                matrixStackIn.translate(0, 0, 0.1D * i);
            }
            matrixStackIn.pop();
    }
}*/
