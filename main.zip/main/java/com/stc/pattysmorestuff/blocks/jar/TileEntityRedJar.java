package com.stc.pattysmorestuff.blocks.jar;

import com.stc.pattysmorestuff.init.ModTileEntities;
import net.minecraft.block.BlockState;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SUpdateTileEntityPacket;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.NonNullList;

import javax.annotation.Nullable;

/*public class TileEntityRedJar extends TileEntity {

    /public int cookieCount = 0;

    public TileEntityRedJar() {
        super(ModTileEntities.RED_JAR);
    }

    public boolean addCookie () {
        if(!world.isRemote) {
            if (cookieCount < 8) {
                cookieCount++;
                markDirty();
                BlockState state = world.getBlockState(pos);
                world.notifyBlockUpdate(pos, state, state, 3);
                return true;
            }
        }
        return false;
    }

    public void removeCookie() {
        if(!world.isRemote) {
            if (cookieCount > 0) {
                world.addEntity(new ItemEntity(world, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, new ItemStack(Items.COOKIE)));
                cookieCount--;
                markDirty();
                BlockState state = world.getBlockState(pos);
                world.notifyBlockUpdate(pos, state, state, 3);
            }
        }
    }

    @Override
    public CompoundNBT write(CompoundNBT compound)
    {

        super.write(compound);
        this.writeUpdateTag(compound);
        return compound;
    }

    @Override
    public void read(CompoundNBT compound) {
        super.read(compound);
        this.readUpdateTag(compound);
    }

    @Override
    public void onDataPacket(NetworkManager net, SUpdateTileEntityPacket pkt) {
        CompoundNBT compound = pkt.getNbtCompound();
        this.read(compound);
    }

    @Nullable
    @Override
    public SUpdateTileEntityPacket getUpdatePacket() {
        return new SUpdateTileEntityPacket(pos, 0, this.getUpdateTag());

    }
    @Override
    public CompoundNBT getUpdateTag() {
        return this.write(new CompoundNBT());
    }

    public void writeUpdateTag(CompoundNBT tag) {
        tag.putInt("CookieCount", this.cookieCount);
    }

    public void readUpdateTag(CompoundNBT tag) {
        this.cookieCount = tag.getInt("CookieCount");
    }

    public int getSize() {
        return 8;
    }

}*/
