package com.stc.pattysmorestuff.blocks.stairs;

import com.stc.pattysmorestuff.PattysMoreStuff;
import com.stc.pattysmorestuff.config.ConfigGeneral;
import com.stc.pattysmorestuff.init.ModBlocks;
import com.stc.pattysmorestuff.init.ModItems;
import com.stc.pattysmorestuff.init.ModTabs;
import net.minecraft.block.BlockState;
import net.minecraft.block.SoundType;
import net.minecraft.block.StairsBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;

public class BlockGlassStairs extends StairsBlock {

    public BlockGlassStairs(String name, BlockState defaultState, Properties properties) {
        super(defaultState, properties.hardnessAndResistance(0.3F).sound(SoundType.GLASS));
        this.setRegistryName(PattysMoreStuff.MODID, name);

        if(ConfigGeneral.disableBlocks.get()) {
            ModBlocks.BLOCKS.add(this);
            ModItems.ITEMS.add(new BlockItem(this, new Item.Properties().group(ModTabs.tabPattysBlocks)).setRegistryName(this.getRegistryName()));
        }
    }

}
