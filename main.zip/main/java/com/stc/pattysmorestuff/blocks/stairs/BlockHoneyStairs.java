package com.stc.pattysmorestuff.blocks.stairs;

import com.stc.pattysmorestuff.PattysMoreStuff;
import com.stc.pattysmorestuff.config.ConfigGeneral;
import com.stc.pattysmorestuff.init.ModBlocks;
import com.stc.pattysmorestuff.init.ModItems;
import com.stc.pattysmorestuff.init.ModTabs;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.StairsBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.item.BoatEntity;
import net.minecraft.entity.item.TNTEntity;
import net.minecraft.entity.item.minecart.AbstractMinecartEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particles.BlockParticleData;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.util.Direction;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.World;
import net.minecraft.loot.LootContext;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.Collections;
import java.util.List;

public class BlockHoneyStairs extends StairsBlock {
    public BlockHoneyStairs(String name, BlockState defaultState, Properties properties) {
        super(defaultState, properties);
        this.setRegistryName(PattysMoreStuff.MODID, name);

        if(ConfigGeneral.disableBlocks.get()) {
            ModBlocks.BLOCKS.add(this);
            ModItems.ITEMS.add(new BlockItem(this, new Item.Properties().group(ModTabs.tabPattysBlocks)).setRegistryName(this.getRegistryName()));
        }
    }

    @Override
    public BlockRenderType getRenderType(BlockState state) {
        return BlockRenderType.MODEL;
    }

    @OnlyIn(Dist.CLIENT)
    public boolean isSideInvisible(BlockState state, BlockState adjacentBlockState, Direction side) {
        return adjacentBlockState.getBlock() == this ? true : super.isSideInvisible(state, adjacentBlockState, side);
    }

    private static boolean func_226937_c_(Entity p_226937_0_) {
        return p_226937_0_ instanceof LivingEntity || p_226937_0_ instanceof AbstractMinecartEntity || p_226937_0_ instanceof TNTEntity || p_226937_0_ instanceof BoatEntity;
    }
    /**
     * Block's chance to react to a living entity falling on it.
     */
    public void onFallenUpon(World worldIn, BlockPos pos, Entity entityIn, float fallDistance) {
        entityIn.playSound(SoundEvents.BLOCK_HONEY_BLOCK_SLIDE, 1.0F, 1.0F);
        if (!worldIn.isRemote) {
            worldIn.setEntityState(entityIn, (byte)54);
        }

        if (entityIn.onLivingFall(fallDistance, 0.2F)) {
            entityIn.playSound(this.soundType.getFallSound(), this.soundType.getVolume() * 0.5F, this.soundType.getPitch() * 0.75F);
        }

    }

    public void onEntityCollision(BlockState state, World worldIn, BlockPos pos, Entity entityIn) {
        if (this.func_226935_a_(pos, entityIn)) {
            this.func_226933_a_(entityIn, pos);
            this.func_226938_d_(entityIn);
            this.func_226934_a_(worldIn, entityIn);
        }

        super.onEntityCollision(state, worldIn, pos, entityIn);
    }

    private boolean func_226935_a_(BlockPos p_226935_1_, Entity p_226935_2_) {
        if (p_226935_2_.func_233570_aj_()) {
            return false;
        } else if (p_226935_2_.getPosY() > (double)p_226935_1_.getY() + 0.9375D - 1.0E-7D) {
            return false;
        } else if (p_226935_2_.getMotion().y >= -0.08D) {
            return false;
        } else {
            double lvt_3_1_ = Math.abs((double)p_226935_1_.getX() + 0.5D - p_226935_2_.getPosX());
            double lvt_5_1_ = Math.abs((double)p_226935_1_.getZ() + 0.5D - p_226935_2_.getPosZ());
            double lvt_7_1_ = 0.4375D + (double)(p_226935_2_.getWidth() / 2.0F);
            return lvt_3_1_ + 1.0E-7D > lvt_7_1_ || lvt_5_1_ + 1.0E-7D > lvt_7_1_;
        }
    }

    private void func_226933_a_(Entity p_226933_1_, BlockPos p_226933_2_) {
        if (p_226933_1_ instanceof ServerPlayerEntity && p_226933_1_.world.getGameTime() % 20L == 0L) {
            CriteriaTriggers.field_229864_K_.func_227152_a_((ServerPlayerEntity)p_226933_1_, p_226933_1_.world.getBlockState(p_226933_2_));
        }

    }

    private void func_226938_d_(Entity p_226938_1_) {
        Vector3d vec3d = p_226938_1_.getMotion();
        if (vec3d.y < -0.13D) {
            double d0 = -0.05D / vec3d.y;
            p_226938_1_.setMotion(new Vector3d(vec3d.x * d0, -0.05D, vec3d.z * d0));
        } else {
            p_226938_1_.setMotion(new Vector3d(vec3d.x, -0.05D, vec3d.z));
        }

        p_226938_1_.fallDistance = 0.0F;
    }

    private void func_226934_a_(World p_226934_1_, Entity p_226934_2_) {
        if (func_226937_c_(p_226934_2_)) {
            if (p_226934_1_.rand.nextInt(5) == 0) {
                p_226934_2_.playSound(SoundEvents.BLOCK_HONEY_BLOCK_SLIDE, 1.0F, 1.0F);
            }

            if (!p_226934_1_.isRemote && p_226934_1_.rand.nextInt(5) == 0) {
                p_226934_1_.setEntityState(p_226934_2_, (byte)53);
            }
        }

    }

    @OnlyIn(Dist.CLIENT)
    public static void func_226931_a_(Entity p_226931_0_) {
        func_226932_a_(p_226931_0_, 5);
    }

    @OnlyIn(Dist.CLIENT)
    public static void func_226936_b_(Entity p_226936_0_) {
        func_226932_a_(p_226936_0_, 10);
    }

    @OnlyIn(Dist.CLIENT)
    private static void func_226932_a_(Entity p_226932_0_, int p_226932_1_) {
        if (p_226932_0_.world.isRemote) {
            BlockState lvt_2_1_ = Blocks.HONEY_BLOCK.getDefaultState();

            for(int lvt_3_1_ = 0; lvt_3_1_ < p_226932_1_; ++lvt_3_1_) {
                p_226932_0_.world.addParticle(new BlockParticleData(ParticleTypes.BLOCK, lvt_2_1_), p_226932_0_.getPosX(), p_226932_0_.getPosY(), p_226932_0_.getPosZ(), 0.0D, 0.0D, 0.0D);
            }

        }
    }

    @Override
    public List<ItemStack> getDrops(BlockState state, LootContext.Builder builder) {
        return (Collections.singletonList(new ItemStack(this)));
    }
}
