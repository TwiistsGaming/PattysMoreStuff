package com.stc.pattysmorestuff.blocks.ore;

import com.stc.pattysmorestuff.PattysMoreStuff;
import com.stc.pattysmorestuff.config.ConfigGeneral;
import com.stc.pattysmorestuff.init.ModBlocks;
import com.stc.pattysmorestuff.init.ModItems;
import com.stc.pattysmorestuff.init.ModTabs;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraft.loot.LootContext;

import javax.annotation.Nullable;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class BlockColoredOre extends Block {
    public BlockColoredOre(String name, Properties properties) {
        super(properties);
        this.setRegistryName(PattysMoreStuff.MODID, name);

        if(ConfigGeneral.disableOres.get()) {
            ModBlocks.BLOCKS.add(this);
            ModItems.ITEMS.add(new BlockItem(this, new Item.Properties().group(ModTabs.tabPattysBlocks)).setRegistryName(this.getRegistryName()));
        }
    }



    @Override
    public void addInformation(ItemStack stack, @Nullable IBlockReader world, List<ITextComponent> tooltip, ITooltipFlag flag) {
        tooltip.add(new StringTextComponent("When mined the block will drop random amounts of dye between [1 - 5] of a single dye type!"));
    }

    protected int func_220281_a(Random p_220281_1_) {
        if (this == ModBlocks.dye_ore) {
            return MathHelper.nextInt(p_220281_1_, 2, 5);
        } else if (this == ModBlocks.dye_ore_nether) {
            return MathHelper.nextInt(p_220281_1_, 2, 5);
        } else if(this == ModBlocks.dye_ore_end) {
            return MathHelper.nextInt(p_220281_1_, 2, 5);
        }else
        {
            return this == Blocks.NETHER_QUARTZ_ORE ? MathHelper.nextInt(p_220281_1_, 2, 5) : 0;
        }
    }

    /**
     * Perform side-effects from block dropping, such as creating silverfish
     */
    public void spawnAdditionalDrops(BlockState state, World worldIn, BlockPos pos, ItemStack stack) {
        super.spawnAdditionalDrops(state, worldIn, pos, stack);
    }

    @Override
    public int getExpDrop(BlockState state, net.minecraft.world.IWorldReader reader, BlockPos pos, int fortune, int silktouch) {
        return silktouch == 0 ? this.func_220281_a(RANDOM) : 0;
    }

    @Override
    public List<ItemStack> getDrops(BlockState state, LootContext.Builder builder) {

        Random random = new Random();

        int drop = random.nextInt(20);

        if(drop == 0) {
            return Collections.singletonList(new ItemStack(Items.BLACK_DYE, random.nextInt(6)));
        }
        if(drop == 1) {
            return Collections.singletonList(new ItemStack(Items.RED_DYE, random.nextInt(6)));
        }
        if(drop == 2) {
            return Collections.singletonList(new ItemStack(Items.GREEN_DYE, random.nextInt(6)));
        }
        if(drop == 3) {
            return Collections.singletonList(new ItemStack(Items.BROWN_DYE, random.nextInt(6)));
        }
        if(drop == 4) {
            return Collections.singletonList(new ItemStack(Items.BLUE_DYE, random.nextInt(6)));
        }
        if(drop == 5) {
            return Collections.singletonList(new ItemStack(Items.PURPLE_DYE, random.nextInt(6)));
        }
        if(drop == 6) {
            return Collections.singletonList(new ItemStack(Items.CYAN_DYE, random.nextInt(6)));
        }
        if(drop == 7) {
            return Collections.singletonList(new ItemStack(Items.LIGHT_GRAY_DYE, random.nextInt(6)));
        }
        if(drop == 8) {
            return Collections.singletonList(new ItemStack(Items.GRAY_DYE, random.nextInt(6)));
        }
        if(drop == 9) {
            return Collections.singletonList(new ItemStack(Items.PINK_DYE, random.nextInt(6)));
        }
        if(drop == 10) {
            return Collections.singletonList(new ItemStack(Items.LIME_DYE, random.nextInt(6)));
        }
        if(drop == 11) {
            return Collections.singletonList(new ItemStack(Items.YELLOW_DYE, random.nextInt(6)));
        }
        if(drop == 12) {
            return Collections.singletonList(new ItemStack(Items.LIGHT_BLUE_DYE, random.nextInt(6)));
        }
        if(drop == 13) {
            return Collections.singletonList(new ItemStack(Items.MAGENTA_DYE, random.nextInt(6)));
        }
        if(drop == 14) {
            return Collections.singletonList(new ItemStack(Items.ORANGE_DYE, random.nextInt(6)));
        }
        if(drop == 15) {
            return Collections.singletonList(new ItemStack(Items.WHITE_DYE, random.nextInt(6)));
        }
        if(drop == 16) {
            return Collections.singletonList(new ItemStack(Items.INK_SAC, random.nextInt(6)));
        }
        if(drop == 17) {
            return Collections.singletonList(new ItemStack(Items.COCOA_BEANS, random.nextInt(6)));
        }
        if(drop == 18) {
            return Collections.singletonList(new ItemStack(Items.LAPIS_LAZULI, random.nextInt(6)));
        }
        if(drop == 19) {
            return Collections.singletonList(new ItemStack(Items.BONE_MEAL, random.nextInt(6)));
        }

        return null;
    }
}
