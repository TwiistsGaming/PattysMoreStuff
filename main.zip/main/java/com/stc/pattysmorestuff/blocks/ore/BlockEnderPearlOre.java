package com.stc.pattysmorestuff.blocks.ore;

import com.stc.pattysmorestuff.PattysMoreStuff;
import com.stc.pattysmorestuff.config.ConfigGeneral;
import com.stc.pattysmorestuff.init.ModBlocks;
import com.stc.pattysmorestuff.init.ModItems;
import com.stc.pattysmorestuff.init.ModTabs;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.item.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraft.loot.LootContext;

import java.util.Collections;
import java.util.List;
import java.util.Random;

public class BlockEnderPearlOre extends Block {
    public BlockEnderPearlOre(String name, Properties properties) {
        super(properties);

        this.setRegistryName(PattysMoreStuff.MODID, name);

        if(ConfigGeneral.disableOres.get()) {
            ModBlocks.BLOCKS.add(this);
            ModItems.ITEMS.add(new BlockItem(this, new Item.Properties().group(ModTabs.tabPattysBlocks)).setRegistryName(this.getRegistryName()));
        }
    }

    protected int func_220281_a(Random p_220281_1_) {
        if (this == ModBlocks.ender_pearl_ore) {
            return MathHelper.nextInt(p_220281_1_, 3, 7);
        } else if (this == ModBlocks.ender_pearl_ore_nether) {
             return MathHelper.nextInt(p_220281_1_, 3, 7);
         } else if (this == ModBlocks.ender_pearl_ore_end) {
            return MathHelper.nextInt(p_220281_1_, 3, 7);
        }else {
            return this == Blocks.NETHER_QUARTZ_ORE ? MathHelper.nextInt(p_220281_1_, 2, 5) : 0;
        }
    }

    public void spawnAdditionalDrops(BlockState state, World worldIn, BlockPos pos, ItemStack stack) {
        super.spawnAdditionalDrops(state, worldIn, pos, stack);
    }

    @Override
    public int getExpDrop(BlockState state, net.minecraft.world.IWorldReader reader, BlockPos pos, int fortune, int silktouch) {
        return silktouch == 0 ? this.func_220281_a(RANDOM) : 0;
    }

    @Override
    public List<ItemStack> getDrops(BlockState p_220076_1_, LootContext.Builder p_220076_2_) {
        return Collections.singletonList(new ItemStack(Items.ENDER_PEARL));
    }
}
