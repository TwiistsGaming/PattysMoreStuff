package com.stc.pattysmorestuff.blocks.blender;

import com.stc.pattysmorestuff.PattysMoreStuff;
import com.stc.pattysmorestuff.config.ConfigGeneral;
import com.stc.pattysmorestuff.init.ModBlocks;
import com.stc.pattysmorestuff.init.ModItems;
import com.stc.pattysmorestuff.init.ModTabs;
import net.minecraft.block.*;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraft.loot.LootContext;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.Collections;
import java.util.List;

public class BlockBlender extends Block {

    protected static final VoxelShape SHAPE = Block.makeCuboidShape(12.0D, 0.5D, 12.0D, 4.0D, 16.0D, 4.0D);

    public BlockBlender(String name, Properties properties) {
        super(properties.hardnessAndResistance(0.8F));
        this.setRegistryName(PattysMoreStuff.MODID, name);

        if(ConfigGeneral.disableBlocks.get()) {
            ModBlocks.BLOCKS.add(this);
            ModItems.ITEMS.add(new BlockItem(this, new Item.Properties().group(ModTabs.tabPattysDecoration)).setRegistryName(this.getRegistryName()));
        }
    }

    @Override
    public VoxelShape getShape(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
        return SHAPE;
    }

    @Override
    public BlockRenderType getRenderType(BlockState p_149645_1_) {
        return BlockRenderType.MODEL;
    }

    @OnlyIn(Dist.CLIENT)
    public boolean isSideInvisible(BlockState p_200122_1_, BlockState p_200122_2_, Direction p_200122_3_) {
        return p_200122_2_.getBlock() == this ? true : super.isSideInvisible(p_200122_1_, p_200122_2_, p_200122_3_);
    }

    @OnlyIn(Dist.CLIENT)
    public float func_220080_a(BlockState p_220080_1_, IBlockReader p_220080_2_, BlockPos p_220080_3_) {
        return 1.0F;
    }

    public boolean propagatesSkylightDown(BlockState p_200123_1_, IBlockReader p_200123_2_, BlockPos p_200123_3_) {
        return true;
    }

    public boolean func_229869_c_(BlockState p_229869_1_, IBlockReader p_229869_2_, BlockPos p_229869_3_) {
        return false;
    }

    public boolean isNormalCube(BlockState p_220081_1_, IBlockReader p_220081_2_, BlockPos p_220081_3_) {
        return false;
    }

    public boolean canEntitySpawn(BlockState p_220067_1_, IBlockReader p_220067_2_, BlockPos p_220067_3_, EntityType<?> p_220067_4_) {
        return false;
    }


    @Override
    public ActionResultType onBlockActivated(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockRayTraceResult rayTraceResult) {

        if(!world.isRemote) {
            if(player.getHeldItemMainhand().getItem() == Items.CARROT) {
                ItemStack CARROT_JUICE = new ItemStack(ModItems.carrot_juice);

                player.setActiveHand(hand);
                player.getHeldItem(hand).shrink(1);
                player.addItemStackToInventory(CARROT_JUICE);
            }

            if (player.getHeldItem(hand).getItem() == Items.MELON) {

                ItemStack MELON_JUICE = new ItemStack(ModItems.melon_juice);

                player.setActiveHand(hand);
                player.getHeldItem(hand).shrink(1);
                player.addItemStackToInventory(MELON_JUICE);
            }

            if (player.getHeldItem(hand).getItem() == Items.BEETROOT) {

                ItemStack BEETROOT_JUICE = new ItemStack(ModItems.beetroot_juice);

                player.setActiveHand(hand);
                player.getHeldItem(hand).shrink(1);
                player.addItemStackToInventory(BEETROOT_JUICE);
            }

            if (player.getHeldItem(hand).getItem() == Items.APPLE) {

                ItemStack APPLE_JUICE = new ItemStack(ModItems.apple_juice);

                player.setActiveHand(hand);
                player.getHeldItem(hand).shrink(1);
                player.addItemStackToInventory(APPLE_JUICE);
            }

            if (player.getHeldItem(hand).getItem() == Item.getItemFromBlock(Blocks.PUMPKIN)) {

                ItemStack PUMPKIN_JUICE = new ItemStack(ModItems.pumpkin_juice);

                player.setActiveHand(hand);
                player.getHeldItem(hand).shrink(1);
                player.addItemStackToInventory(PUMPKIN_JUICE);
            }
        }
        return ActionResultType.FAIL;
    }

    @Override
    public List<ItemStack> getDrops(BlockState state, LootContext.Builder builder) {
        return (Collections.singletonList(new ItemStack(this)));
    }
}
