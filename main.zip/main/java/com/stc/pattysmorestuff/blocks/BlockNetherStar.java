package com.stc.pattysmorestuff.blocks;

import com.stc.pattysmorestuff.PattysMoreStuff;
import com.stc.pattysmorestuff.blocks.items.ItemStarBlock;
import com.stc.pattysmorestuff.config.ConfigGeneral;
import com.stc.pattysmorestuff.init.ModBlocks;
import com.stc.pattysmorestuff.init.ModItems;
import com.stc.pattysmorestuff.init.ModTabs;
import net.minecraft.block.Block;
import net.minecraft.item.Item;


public class BlockNetherStar extends Block {

    public BlockNetherStar(String name, Properties properties) {
        super(properties);
        this.setRegistryName(PattysMoreStuff.MODID, name);

        if(ConfigGeneral.disableBlocks.get()) {
            ModBlocks.BLOCKS.add(this);
            ModItems.ITEMS.add(new ItemStarBlock(this, new Item.Properties().group(ModTabs.tabPattysBlocks)).setRegistryName(this.getRegistryName()));
        }
    }
}
