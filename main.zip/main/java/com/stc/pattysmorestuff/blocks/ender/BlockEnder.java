package com.stc.pattysmorestuff.blocks.ender;

import com.stc.pattysmorestuff.blocks.BlockBase;

public class BlockEnder extends BlockBase {

    public BlockEnder(String name, Properties properties) {
        super(name, properties);
    }

}
