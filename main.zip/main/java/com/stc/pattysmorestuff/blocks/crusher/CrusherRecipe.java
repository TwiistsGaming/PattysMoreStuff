package com.stc.pattysmorestuff.blocks.crusher;

import com.stc.pattysmorestuff.init.ModBlocks;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipeSerializer;
import net.minecraft.item.crafting.IRecipeType;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.util.ResourceLocation;

public class CrusherRecipe extends AbstractCustomRecipe {
    public static final IRecipeType<CrusherRecipe> RECIPE_TYPE = new IRecipeType<CrusherRecipe>() {
        @Override
        public String toString() {
            return "pattysmorestuff:crushing";
        }
    };

    public CrusherRecipe(ResourceLocation idIn, Ingredient ingredientIn, ItemStack resultIn) {
        super(RECIPE_TYPE, idIn, ingredientIn, resultIn);
    }

    public ItemStack getIcon() {
        return new ItemStack(ModBlocks.crusher);
    }

    public IRecipeSerializer<?> getSerializer() {
        return PMSCrusher.CRUSHER;
    }
}
