package com.stc.pattysmorestuff.blocks.crusher;

import com.google.gson.*;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.*;
import net.minecraft.network.PacketBuffer;
import net.minecraft.util.JSONUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.registry.Registry;


public class CrusherRecipeSerializer<T extends AbstractCustomRecipe> extends net.minecraftforge.registries.ForgeRegistryEntry<IRecipeSerializer<?>> implements IRecipeSerializer<T> {
    public final CrusherRecipeSerializer.IFactory<T> factory;

    public CrusherRecipeSerializer(IFactory<T> p_i50025_1_) {
        this.factory = p_i50025_1_;
    }

    public T read(ResourceLocation recipeId, JsonObject json) {
        JsonElement jsonelement = (JsonElement) (JSONUtils.isJsonArray(json, "ingredient") ?
                JSONUtils.getJsonArray(json, "ingredient") :
                JSONUtils.getJsonObject(json, "ingredient"));
        Ingredient ingredient = Ingredient.deserialize(jsonelement);
        //Forge: Check if primitive string to keep vanilla or a object which can contain a count field.
        if (!json.has("result"))
            throw new com.google.gson.JsonSyntaxException("Missing result, expected to find a string or object");
        ItemStack itemstack;
        if (json.get("result").isJsonObject())
            itemstack = ShapedRecipe.deserializeItem(JSONUtils.getJsonObject(json, "result"));
        else {
            String s1 = JSONUtils.getString(json, "result");
            ResourceLocation resourcelocation = new ResourceLocation(s1);
            itemstack = new ItemStack(Registry.ITEM.getValue(resourcelocation).orElseThrow(() -> {
                return new IllegalStateException("Item: " + s1 + " does not exist");
            }));
        }
        return this.factory.create(recipeId, ingredient, itemstack);
    }

    public T read(ResourceLocation recipeId, PacketBuffer buffer) {
        Ingredient ingredient = Ingredient.read(buffer);
        ItemStack itemstack = buffer.readItemStack();
        return this.factory.create(recipeId, ingredient, itemstack);
    }

    public void write(PacketBuffer buffer, T recipe) {
        recipe.ingredient.write(buffer);
        buffer.writeItemStack(recipe.result);
    }

    public  interface IFactory<T extends AbstractCustomRecipe> {
        T create(ResourceLocation p_create_1_, Ingredient p_create_3_, ItemStack p_create_4_);
    }
}

