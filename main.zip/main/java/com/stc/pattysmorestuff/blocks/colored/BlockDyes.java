package com.stc.pattysmorestuff.blocks.colored;

import com.stc.pattysmorestuff.blocks.BlockBase;

public class BlockDyes extends BlockBase {

    public BlockDyes(String name, Properties properties) {
        super(name, properties);

    }

}
