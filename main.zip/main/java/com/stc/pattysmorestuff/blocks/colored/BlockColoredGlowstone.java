package com.stc.pattysmorestuff.blocks.colored;

import com.stc.pattysmorestuff.PattysMoreStuff;
import com.stc.pattysmorestuff.init.ModBlocks;
import com.stc.pattysmorestuff.init.ModItems;
import com.stc.pattysmorestuff.init.ModTabs;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;

public class BlockColoredGlowstone extends Block {

    public BlockColoredGlowstone(String name, Properties properties) {
        super(properties.hardnessAndResistance(0.3F).sound(SoundType.GLASS).func_235838_a_((p_235464_0_) -> {
            return 15;
        }));
        this.setRegistryName(PattysMoreStuff.MODID, name);

        ModBlocks.BLOCKS.add(this);
        ModItems.ITEMS.add(new BlockItem(this, new Item.Properties().group(ModTabs.tabPattysBlocks)).setRegistryName(this.getRegistryName()));

    }
}
