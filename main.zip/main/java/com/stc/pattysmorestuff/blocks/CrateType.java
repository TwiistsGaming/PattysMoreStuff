package com.stc.pattysmorestuff.blocks;

import com.stc.pattysmorestuff.PattysMoreStuff;
import com.stc.pattysmorestuff.init.ModBlocks;
import com.stc.pattysmorestuff.tileentity.crates.*;
import net.minecraft.block.BlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.ResourceLocation;

public enum CrateType implements IStringSerializable
{
    OAK(54, 9, "oak_storage_crate.png", OakCrateTileEntity.class, "oak_storage_crate", 184, 222, new ResourceLocation(PattysMoreStuff.MODID, "textures/gui/container/oak_crate.png"), 256, 256),
    SPRUCE(54, 9, "spruce_storage_crate.png", SpruceCrateTileEntity.class, "spruce_storage_crate", 184, 222, new ResourceLocation(PattysMoreStuff.MODID, "textures/gui/container/spruce_crate.png"), 256, 256),
    BIRCH(54, 9, "birch_storage_crate.png", BirchCrateTileEntity.class, "birch_storage_crate", 184, 222, new ResourceLocation(PattysMoreStuff.MODID, "textures/gui/container/birch_crate.png"), 256, 256),
    JUNGLE(54, 9, "jungle_storage_crate.png", JungleCrateTileEntity.class, "jungle_storage_crate", 184, 222, new ResourceLocation(PattysMoreStuff.MODID, "textures/gui/container/jungle_crate.png"), 256, 256),
    ACACIA(54, 9, "acacia_storage_crate.png", AcaciaCrateTileEntity.class, "acacia_storage_crate", 184, 222, new ResourceLocation(PattysMoreStuff.MODID, "textures/gui/container/acacia_crate.png"), 256, 256),
    BIG_OAK(54, 9, "big_oak_storage_crate.png", DarkOakCrateTileEntity.class, "big_oak_storage_crate", 184, 222, new ResourceLocation(PattysMoreStuff.MODID, "textures/gui/container/big_oak_crate.png"), 256, 256),
    WOOD(0, 0, "", null, null, 0, 0, null, 0, 0);

    public static final CrateType VALUES[] = values();

    public final String name;

    public final int size;

    public final int rowLength;

    public final String modelTexture;

    public final Class<? extends TileEntity> clazz;

    public final String itemName;

    public final int xSize;

    public final int ySize;

    public final ResourceLocation guiTexture;

    public final int textureXSize;

    public final int textureYSize;

    CrateType(int size, int rowLength, String modelTexture, Class<? extends TileEntity> clazz, String itemName, int xSize, int ySize, ResourceLocation guiTexture, int textureXSize, int textureYSize)
    {
        this.name = this.name().toLowerCase();
        this.size = size;
        this.rowLength = rowLength;
        this.modelTexture = modelTexture;
        this.clazz = clazz;
        this.itemName = itemName;
        this.xSize = xSize;
        this.ySize = ySize;
        this.guiTexture = guiTexture;
        this.textureXSize = textureXSize;
        this.textureYSize = textureYSize;
    }

    public int getRowCount()
    {
        return this.size / this.rowLength;
    }

    public static CrateType get(ResourceLocation resourceLocation)
    {
        switch (resourceLocation.toString())
        {
            case "oak_storage_crate":
                return OAK;
            case "spruce_storage_crate":
                return SPRUCE;
            case "birch_storage_crate":
                return BIRCH;
            case "jungle_storage_crate":
                return JUNGLE;
            case "acacia_storage_crate":
                return ACACIA;
            case "big_oak_storage_crate":
                return BIG_OAK;
            default:
                return WOOD;
        }
    }

    public static BlockState get(CrateType type)
    {
        switch (type)
        {
            case OAK:
                return ModBlocks.oak_storage_crate.getDefaultState();
            case SPRUCE:
                return ModBlocks.spruce_storage_crate.getDefaultState();
            case BIRCH:
                return ModBlocks.birch_storage_crate.getDefaultState();
            case JUNGLE:
                return ModBlocks.jungle_storage_crate.getDefaultState();
            case ACACIA:
                return ModBlocks.acacia_storage_crate.getDefaultState();
            case BIG_OAK:
                return ModBlocks.big_oak_storage_crate.getDefaultState();
            default:
                return null;
        }
    }

    public TileEntity makeEntity()
    {
        switch (this)
        {
            case OAK:
                return new OakCrateTileEntity();
            case SPRUCE:
                return new SpruceCrateTileEntity();
            default:
                return null;
        }
    }

    @Override
    public String func_176610_l() {
        return null;
    }
}
