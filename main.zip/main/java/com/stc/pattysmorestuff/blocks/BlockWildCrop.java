package com.stc.pattysmorestuff.blocks;

import com.stc.pattysmorestuff.PattysMoreStuff;
import com.stc.pattysmorestuff.config.ConfigGeneral;
import com.stc.pattysmorestuff.init.ModBlocks;
import com.stc.pattysmorestuff.init.ModItems;
import net.minecraft.block.*;
import net.minecraft.item.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;
import java.util.Random;


public class BlockWildCrop extends BushBlock implements net.minecraftforge.common.IForgeShearable {

    public BlockWildCrop(String name, Properties builder) {
        super(builder);
        this.setRegistryName(PattysMoreStuff.MODID, name);
        if(ConfigGeneral.disableWildCrop.get()) {
            ModBlocks.BLOCKS.add(this);
            ModItems.ITEMS.add(new BlockItem(this, new Item.Properties()).setRegistryName(this.getRegistryName()));
        }
    }



    @Override
    public boolean isShearable(ItemStack item, World world, BlockPos pos) {
        return true;
    }

    @Override
    public OffsetType getOffsetType() {
        return OffsetType.XZ;
    }

    public static void generateBush(IWorld world, BlockPos pos, Random random)
    {
        world.setBlockState(pos, ModBlocks.wild_crop.getDefaultState(), 3);
    }


}
