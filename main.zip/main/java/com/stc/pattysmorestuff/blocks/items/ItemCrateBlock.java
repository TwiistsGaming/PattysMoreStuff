package com.stc.pattysmorestuff.blocks.items;

import net.minecraft.block.Block;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;

public class ItemCrateBlock extends BlockItem {

    protected final Block block;

    public ItemCrateBlock(Block blockIn, Properties builder) {
        super(blockIn, builder);
        this.block = blockIn;

    }

    @Override
    public int getBurnTime(ItemStack itemStack) {
        return 15;
    }
}
