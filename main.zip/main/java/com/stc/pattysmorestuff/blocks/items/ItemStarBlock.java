package com.stc.pattysmorestuff.blocks.items;

import net.minecraft.block.Block;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;

public class ItemStarBlock extends BlockItem {

    protected final Block block;

    public ItemStarBlock(Block blockIn, Properties builder) {
        super(blockIn, builder);
        this.block = blockIn;
    }

    @Override
    public boolean hasEffect(ItemStack stack) {
        return true;
    }
}
