package com.stc.pattysmorestuff.blocks.crate;

import com.stc.pattysmorestuff.blocks.CrateType;
import com.stc.pattysmorestuff.tileentity.crates.OakCrateTileEntity;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.ContainerBlock;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityMerger;
import net.minecraft.tileentity.TileEntityType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.function.Supplier;

public abstract class AbstractCrateBlock <E extends TileEntity> extends ContainerBlock {
    protected final CrateType tileEntityType;

    protected AbstractCrateBlock(Properties builder, CrateType tileEntityTypeSupplier) {
        super(builder);
        this.tileEntityType = tileEntityTypeSupplier;
    }

    @OnlyIn(Dist.CLIENT)
    public abstract TileEntityMerger.ICallbackWrapper<? extends OakCrateTileEntity> func_225536_a_(BlockState p_225536_1_, World p_225536_2_, BlockPos p_225536_3_, boolean p_225536_4_);
}
