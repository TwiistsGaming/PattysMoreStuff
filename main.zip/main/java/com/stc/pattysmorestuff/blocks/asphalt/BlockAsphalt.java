package com.stc.pattysmorestuff.blocks.asphalt;

import com.stc.pattysmorestuff.blocks.BlockBase;

public class BlockAsphalt extends BlockBase {

    public BlockAsphalt(String name, Properties properties) {
        super(name, properties);
    }

}
