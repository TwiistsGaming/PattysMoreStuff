package com.stc.pattysmorestuff.blocks.asphalt;

import com.stc.pattysmorestuff.PattysMoreStuff;
import com.stc.pattysmorestuff.config.ConfigGeneral;
import com.stc.pattysmorestuff.init.ModBlocks;
import com.stc.pattysmorestuff.init.ModItems;
import com.stc.pattysmorestuff.init.ModTabs;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.HorizontalBlock;
import net.minecraft.block.material.PushReaction;
import net.minecraft.item.*;
import net.minecraft.state.StateContainer;
import net.minecraft.loot.LootContext;

import java.util.Collections;
import java.util.List;

public class BlockAsphaltCenter extends HorizontalBlock {



    public BlockAsphaltCenter(String name, Properties properties) {
        super(properties);
        this.setRegistryName(PattysMoreStuff.MODID, name);

        if(ConfigGeneral.disableBlocks.get()) {
            ModBlocks.BLOCKS.add(this);
            ModItems.ITEMS.add(new BlockItem(this, new Item.Properties().group(ModTabs.tabPattysBlocks)).setRegistryName(this.getRegistryName()));
        }
    }


    protected void fillStateContainer(StateContainer.Builder<Block, BlockState> builder) {
        builder.add(HORIZONTAL_FACING);
    }

    public BlockState getStateForPlacement(BlockItemUseContext context) {
        return this.getDefaultState().with(HORIZONTAL_FACING, context.getPlacementHorizontalFacing().getOpposite());
    }

    public PushReaction getPushReaction(BlockState state) {
        return PushReaction.PUSH_ONLY;
    }

    @Override
    public List<ItemStack> getDrops(BlockState state, LootContext.Builder builder) {
        return (Collections.singletonList(new ItemStack(this)));
    }

}
