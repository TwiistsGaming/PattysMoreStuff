package com.stc.pattysmorestuff.init;


public class ModRecipes {

    public static void init() {
        //IRecipeSerializer.register(DyeBackpackRecipe.NAME.toString(), DyeBackpackRecipe.SERIALIZER);
    }
}
