package com.stc.pattysmorestuff.init;

import com.stc.pattysmorestuff.blocks.crusher.CrusherScreen;
import com.stc.pattysmorestuff.items.backpack.BackpackGui;
import com.stc.pattysmorestuff.tileentity.crates.containers.CrateScreen;
import com.stc.pattysmorestuff.util.ContainerTypes;
import net.minecraft.client.gui.ScreenManager;

public class ModScreens {

    public static void init() {
        /*ScreenManager.registerFactory(ContainerTypes.OAK_CRATE, CrateScreen::new);
        ScreenManager.registerFactory(ContainerTypes.SPRUCE_CRATE, CrateScreen::new);
        ScreenManager.registerFactory(ContainerTypes.BIRCH_CRATE, CrateScreen::new);
        ScreenManager.registerFactory(ContainerTypes.JUNGLE_CRATE, CrateScreen::new);
        ScreenManager.registerFactory(ContainerTypes.ACACIA_CRATE, CrateScreen::new);
        ScreenManager.registerFactory(ContainerTypes.BIG_OAK_CRATE, CrateScreen::new);*/
        ScreenManager.registerFactory(ContainerTypes.CRUSHER, CrusherScreen::new);
        ScreenManager.registerFactory(ContainerTypes.BACKPACK, BackpackGui::new);

    }
}
