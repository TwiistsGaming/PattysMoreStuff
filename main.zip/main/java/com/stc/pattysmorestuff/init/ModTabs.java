package com.stc.pattysmorestuff.init;

import com.stc.pattysmorestuff.config.ConfigGeneral;
import net.minecraft.item.*;

public class ModTabs {

    public static ItemGroup tabPattysBlocks;
    public static ItemGroup tabPattysDecoration;
    public static ItemGroup tabPattysButtons;
    public static ItemGroup tabPattysMisc;
    public static ItemGroup tabPattysFood;
    public static ItemGroup tabPattysTools;
    public static ItemGroup tabPattysCombat;

    public static void pattysTabs() {

        if(ConfigGeneral.disableBlocks.get()) {
            tabPattysBlocks = new ItemGroup(ItemGroup.getGroupCountSafe(), "Blocks") {
                @Override
                public ItemStack createIcon() {
                    return new ItemStack(ModBlocks.dye_block_black);
                }

                @Override
                public String getTranslationKey() {
                    return "Pattys Blocks";
                }
            };

            tabPattysDecoration = new ItemGroup(ItemGroup.getGroupCountSafe(), "Decoration") {
                @Override
                public ItemStack createIcon() {
                    return new ItemStack(ModBlocks.crusher);
                }

                @Override
                public String getTranslationKey() {
                    return "Pattys Decoration";
                }
            };

            tabPattysButtons = new ItemGroup(ItemGroup.getGroupCountSafe(), "Buttons") {
                @Override
                public ItemStack createIcon() {
                    return new ItemStack(ModBlocks.blue_button);
                }

                @Override
                public String getTranslationKey() {
                    return "Pattys Buttons";
                }
            };

        }
        tabPattysMisc = new ItemGroup(ItemGroup.getGroupCountSafe(), "Misc") {
            @Override
            public ItemStack createIcon() {
                return new ItemStack(ModItems.obsidian_ingot);
            }

            @Override
            public String getTranslationKey() {
                return "Pattys Misc";
            }
        };

        if(ConfigGeneral.disableFood.get()) {

            tabPattysFood = new ItemGroup(ItemGroup.getGroupCountSafe(), "Food") {
                @Override
                public ItemStack createIcon() {
                    return new ItemStack(ModItems.bacon_cooked);
                }

                @Override
                public String getTranslationKey() {
                    return "Pattys Food";
                }
            };
        }
        if(ConfigGeneral.disableTools.get()) {

            tabPattysTools = new ItemGroup(ItemGroup.getGroupCountSafe(), "Tools") {
                @Override
                public ItemStack createIcon() {
                    return new ItemStack(ModItems.obsidian_axe);
                }

                @Override
                public String getTranslationKey() {
                    return "Pattys Tools";
                }
            };
        }
        tabPattysCombat = new ItemGroup(ItemGroup.getGroupCountSafe(), "Combat") {
                @Override
                public ItemStack createIcon() {
                        return new ItemStack(ModItems.ender_sword);
                }

                @Override
                public String getTranslationKey() {
                        return "Pattys Combat";
                }
        };
    }
}
