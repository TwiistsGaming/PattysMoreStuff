package com.stc.pattysmorestuff.init;

import com.stc.pattysmorestuff.handlers.PattysArmorMaterial;
import com.stc.pattysmorestuff.handlers.PattysToolMaterial;
import com.stc.pattysmorestuff.items.*;
import com.stc.pattysmorestuff.items.armor.ItemMoreArmor;
import com.stc.pattysmorestuff.items.armor.ItemStarArmor;
import com.stc.pattysmorestuff.items.backpack.ItemBackpack;
import com.stc.pattysmorestuff.items.bows.ItemCustomBow;
import com.stc.pattysmorestuff.items.drinks.ItemChocolateMilk;
import com.stc.pattysmorestuff.items.drinks.ItemDrinkable;
import com.stc.pattysmorestuff.items.drinks.ItemMilkBottle;
import com.stc.pattysmorestuff.items.excavator.ItemExcavator;
import com.stc.pattysmorestuff.items.excavator.ItemNstarExcavator;
import com.stc.pattysmorestuff.items.foods.ItemCustomFood;
import com.stc.pattysmorestuff.items.foods.PattysFoods;
import com.stc.pattysmorestuff.items.hammers.ItemCustomHammer;
import com.stc.pattysmorestuff.items.hammers.ItemNstarHammer;
import com.stc.pattysmorestuff.items.infbuckets.ItemInfLavaBucket;
import com.stc.pattysmorestuff.items.infbuckets.ItemInfWaterBucket;
import com.stc.pattysmorestuff.items.lumberaxe.ItemLumberAxe;
import com.stc.pattysmorestuff.items.lumberaxe.ItemNstarLumberAxe;
import com.stc.pattysmorestuff.items.scythes.ItemCustomScythe;
import com.stc.pattysmorestuff.items.scythes.ItemNStarScythe;
import com.stc.pattysmorestuff.items.tools.*;
import com.stc.pattysmorestuff.items.wand.ItemLightWand;
import net.minecraft.fluid.Fluids;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.*;

import java.util.ArrayList;
import java.util.List;

public class ModItems {

    public static final List<Item> ITEMS = new ArrayList<Item>();

    public static Item obsidian_ingot =  new ItemObsidianIngot("obsidian_ingot", new Item.Properties().group(ModTabs.tabPattysMisc));
    public static Item obsidian_chunk = new ItemBase("obsidian_chunk", new Item.Properties().group(ModTabs.tabPattysMisc));

    public static Item inf_water_bucket = new ItemInfWaterBucket("inf_water_bucket", Fluids.WATER, new Item.Properties().group(ModTabs.tabPattysMisc));
    public static Item inf_lava_bucket = new ItemInfLavaBucket("inf_lava_bucket", Fluids.LAVA, new Item.Properties().group(ModTabs.tabPattysMisc));

    //public static Item time_wand = new ItemTimeWand("time_wand", new Item.Properties().group(ModTabs.tabPattysMisc));
    public static Item light_wand = new ItemLightWand("light_wand", new Item.Properties().group(ModTabs.tabPattysMisc));
    //public static Item weather_wand = new ItemWeatherWand("weather_wand", new Item.Properties().group(ModTabs.tabPattysMisc));

    public static Item knife = new ItemKnife("knife", new Item.Properties().group(ModTabs.tabPattysMisc));
    public static Item wrench = new ItemWrench("wrench", new Item.Properties().group(ModTabs.tabPattysMisc));

    public static Item iron_dust = new ItemBase("iron_dust", new Item.Properties().group(ModTabs.tabPattysMisc));
    public static Item gold_dust = new ItemBase("gold_dust", new Item.Properties().group(ModTabs.tabPattysMisc));
    public static Item obsidian_dust = new ItemBase("obsidian_dust", new Item.Properties().group(ModTabs.tabPattysMisc));
    public static Item diamond_dust = new ItemBase("diamond_dust", new Item.Properties().group(ModTabs.tabPattysMisc));
    public static Item emerald_dust = new ItemBase("emerald_dust", new Item.Properties().group(ModTabs.tabPattysMisc));
    public static Item coal_dust = new ItemBase("coal_dust", new Item.Properties().group(ModTabs.tabPattysMisc));

    public static Item nstar_pickaxe = new ItemCustomPickaxe("nstar_pickaxe", PattysToolMaterial.NSTAR,1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item nstar_axe = new ItemCustomAxe("nstar_axe", PattysToolMaterial.NSTAR,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item nstar_shovel = new ItemCustomSpade("nstar_shovel", PattysToolMaterial.NSTAR, 1.5F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item nstar_hoe = new ItemCustomHoe("nstar_hoe", PattysToolMaterial.NSTAR, -3,0.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item nstar_sword = new ItemCustomSword("nstar_sword", PattysToolMaterial.NSTAR, 3, -2.4F, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item nstar_paxel = new ItemPaxel("nstar_paxel", PattysToolMaterial.NSTAR_PAXEL, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item netherstar_battle_axe = new ItemBattleaxe("netherstar_battle_axe", PattysToolMaterial.NSTAR,3, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item nstar_bow = new ItemCustomBow("nstar_bow", new Item.Properties().group(ModTabs.tabPattysCombat).defaultMaxDamage(PattysToolMaterial.NSTAR.getMaxUses()));
    public static Item nstar_scythe = new ItemNStarScythe("nstar_scythe", new Item.Properties().group(ModTabs.tabPattysTools).defaultMaxDamage(PattysToolMaterial.NSTAR.getMaxUses()));
    public static Item nstar_hammer = new ItemNstarHammer("nstar_hammer", PattysToolMaterial.NSTAR, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item nstar_lumber_axe = new ItemNstarLumberAxe("nstar_lumber_axe", PattysToolMaterial.NSTAR,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item nstar_excavator = new ItemNstarExcavator("nstar_excavator", PattysToolMaterial.NSTAR,1, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));

    public static Item nether_star_helmet = new ItemStarArmor("nether_star_helmet", PattysArmorMaterial.NSTAR,"nether_star", EquipmentSlotType.HEAD, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item nether_star_chestplate = new ItemStarArmor("nether_star_chestplate", PattysArmorMaterial.NSTAR, "nether_star", EquipmentSlotType.CHEST, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item nether_star_leggings = new ItemStarArmor("nether_star_leggings", PattysArmorMaterial.NSTAR, "nether_star", EquipmentSlotType.LEGS, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item nether_star_boots = new ItemStarArmor("nether_star_boots", PattysArmorMaterial.NSTAR,"nether_star",EquipmentSlotType.FEET, new Item.Properties().group(ModTabs.tabPattysCombat));

    public static Item emerald_pickaxe = new ItemCustomPickaxe("emerald_pickaxe", PattysToolMaterial.EMERALD,1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item emerald_axe = new ItemCustomAxe("emerald_axe", PattysToolMaterial.EMERALD,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item emerald_shovel = new ItemCustomSpade("emerald_shovel", PattysToolMaterial.EMERALD, 1.5F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item emerald_sword = new ItemCustomSword("emerald_sword", PattysToolMaterial.EMERALD, 3, -2.4F, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item emerald_hoe = new ItemCustomHoe("emerald_hoe", PattysToolMaterial.EMERALD, -3, 0.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item emerald_paxel = new ItemPaxel("emerald_paxel", PattysToolMaterial.EMERALD_PAXEL, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item emerald_battle_axe = new ItemBattleaxe("emerald_battle_axe", PattysToolMaterial.EMERALD,3, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item emerald_bow = new ItemCustomBow("emerald_bow", new Item.Properties().group(ModTabs.tabPattysCombat).defaultMaxDamage(PattysToolMaterial.EMERALD.getMaxUses()));
    public static Item emerald_scythe = new ItemCustomScythe("emerald_scythe", new Item.Properties().group(ModTabs.tabPattysTools).defaultMaxDamage(PattysToolMaterial.EMERALD.getMaxUses()));
    public static Item emerald_hammer = new ItemCustomHammer("emerald_hammer", PattysToolMaterial.EMERALD, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item emerald_lumber_axe = new ItemLumberAxe("emerald_lumber_axe", PattysToolMaterial.EMERALD,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item emerald_excavator = new ItemExcavator("emerald_excavator", PattysToolMaterial.EMERALD,1, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));

    public static Item emerald_helmet = new ItemMoreArmor("emerald_helmet", PattysArmorMaterial.EMERALD,"emerald", EquipmentSlotType.HEAD, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item emerald_chestplate = new ItemMoreArmor("emerald_chestplate", PattysArmorMaterial.EMERALD,"emerald", EquipmentSlotType.CHEST, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item emerald_leggings = new ItemMoreArmor("emerald_leggings", PattysArmorMaterial.EMERALD,"emerald", EquipmentSlotType.LEGS, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item emerald_boots = new ItemMoreArmor("emerald_boots", PattysArmorMaterial.EMERALD,"emerald", EquipmentSlotType.FEET, new Item.Properties().group(ModTabs.tabPattysCombat));

    public static Item obsidian_pickaxe = new ItemCustomPickaxe("obsidian_pickaxe", PattysToolMaterial.OBSIDIAN,1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item obsidian_axe = new ItemCustomAxe("obsidian_axe", PattysToolMaterial.OBSIDIAN,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item obsidian_shovel = new ItemCustomSpade("obsidian_shovel", PattysToolMaterial.OBSIDIAN, 1.5F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item obsidian_sword = new ItemCustomSword("obsidian_sword", PattysToolMaterial.OBSIDIAN, 3, -2.4F, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item obsidian_hoe = new ItemCustomHoe("obsidian_hoe", PattysToolMaterial.OBSIDIAN, -3, 0.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item obsidian_paxel = new ItemPaxel("obsidian_paxel", PattysToolMaterial.OBSIDIAN_PAXEL, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item obsidian_battle_axe = new ItemBattleaxe("obsidian_battle_axe", PattysToolMaterial.OBSIDIAN,3, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item obsidian_bow = new ItemCustomBow("obsidian_bow", new Item.Properties().group(ModTabs.tabPattysCombat).defaultMaxDamage(PattysToolMaterial.OBSIDIAN.getMaxUses()));
    public static Item obsidian_scythe = new ItemCustomScythe("obsidian_scythe", new Item.Properties().group(ModTabs.tabPattysTools).defaultMaxDamage(PattysToolMaterial.OBSIDIAN.getMaxUses()));
    public static Item obsidian_hammer = new ItemCustomHammer("obsidian_hammer", PattysToolMaterial.OBSIDIAN, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item obsidian_lumber_axe = new ItemLumberAxe("obsidian_lumber_axe", PattysToolMaterial.OBSIDIAN,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item obsidian_excavator = new ItemExcavator("obsidian_excavator", PattysToolMaterial.OBSIDIAN,1, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));

    public static Item obsidian_helmet = new ItemMoreArmor("obsidian_helmet", PattysArmorMaterial.OBSIDIAN,"obsidian", EquipmentSlotType.HEAD, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item obsidian_chestplate = new ItemMoreArmor("obsidian_chestplate", PattysArmorMaterial.OBSIDIAN,"obsidian", EquipmentSlotType.CHEST, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item obsidian_leggings = new ItemMoreArmor("obsidian_leggings", PattysArmorMaterial.OBSIDIAN,"obsidian", EquipmentSlotType.LEGS, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item obsidian_boots = new ItemMoreArmor("obsidian_boots", PattysArmorMaterial.OBSIDIAN,"obsidian", EquipmentSlotType.FEET, new Item.Properties().group(ModTabs.tabPattysCombat));

    public static Item ender_pickaxe = new ItemCustomPickaxe("ender_pickaxe", PattysToolMaterial.ENDER,1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item ender_axe = new ItemCustomAxe("ender_axe", PattysToolMaterial.ENDER,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item ender_shovel = new ItemCustomSpade("ender_shovel", PattysToolMaterial.ENDER, 1.5F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item ender_hoe = new ItemCustomHoe("ender_hoe", PattysToolMaterial.ENDER, -3, 0.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item ender_sword = new ItemCustomSword("ender_sword", PattysToolMaterial.ENDER, 3, -2.4F, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item ender_paxel = new ItemPaxel("ender_paxel", PattysToolMaterial.ENDER_PAXEL, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item ender_battle_axe = new ItemBattleaxe("ender_battle_axe", PattysToolMaterial.ENDER,3, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item ender_bow = new ItemCustomBow("ender_bow", new Item.Properties().group(ModTabs.tabPattysCombat).defaultMaxDamage(PattysToolMaterial.ENDER.getMaxUses()));
    public static Item ender_scythe = new ItemCustomScythe("ender_scythe", new Item.Properties().group(ModTabs.tabPattysTools).defaultMaxDamage(PattysToolMaterial.ENDER.getMaxUses()));
    public static Item ender_hammer = new ItemCustomHammer("ender_hammer", PattysToolMaterial.ENDER, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item ender_lumber_axe = new ItemLumberAxe("ender_lumber_axe", PattysToolMaterial.ENDER,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item ender_excavator = new ItemExcavator("ender_excavator", PattysToolMaterial.ENDER,1, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));

    public static Item ender_helmet = new ItemMoreArmor("ender_helmet", PattysArmorMaterial.ENDER,"ender", EquipmentSlotType.HEAD, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item ender_chestplate = new ItemMoreArmor("ender_chestplate", PattysArmorMaterial.ENDER,"ender", EquipmentSlotType.CHEST, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item ender_leggings = new ItemMoreArmor("ender_leggings", PattysArmorMaterial.ENDER,"ender", EquipmentSlotType.LEGS , new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item ender_boots = new ItemMoreArmor("ender_boots", PattysArmorMaterial.ENDER,"ender", EquipmentSlotType.FEET, new Item.Properties().group(ModTabs.tabPattysCombat));

    public static Item coal_pickaxe = new ItemCustomPickaxe("coal_pickaxe", PattysToolMaterial.COAL,1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item coal_axe = new ItemCustomAxe("coal_axe", PattysToolMaterial.COAL,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item coal_shovel = new ItemCustomSpade("coal_shovel", PattysToolMaterial.COAL, 1.5F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item coal_hoe = new ItemCustomHoe("coal_hoe", PattysToolMaterial.COAL, -3, 0.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item coal_sword = new ItemCustomSword("coal_sword", PattysToolMaterial.COAL, 3, -2.4F, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item coal_paxel = new ItemPaxel("coal_paxel", PattysToolMaterial.COAL_PAXEL, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item coal_battle_axe = new ItemBattleaxe("coal_battle_axe", PattysToolMaterial.COAL,3, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item coal_bow = new ItemCustomBow("coal_bow", new Item.Properties().group(ModTabs.tabPattysCombat).defaultMaxDamage(PattysToolMaterial.COAL.getMaxUses()));
    public static Item coal_scythe = new ItemCustomScythe("coal_scythe", new Item.Properties().group(ModTabs.tabPattysTools).defaultMaxDamage(PattysToolMaterial.COAL.getMaxUses()));
    public static Item coal_hammer = new ItemCustomHammer("coal_hammer", PattysToolMaterial.COAL, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item coal_lumber_axe = new ItemLumberAxe("coal_lumber_axe", PattysToolMaterial.COAL,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item coal_excavator = new ItemExcavator("coal_excavator", PattysToolMaterial.COAL,1, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));

    public static Item coal_helmet = new ItemMoreArmor("coal_helmet", PattysArmorMaterial.COAL,"coal", EquipmentSlotType.HEAD, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item coal_chestplate = new ItemMoreArmor("coal_chestplate", PattysArmorMaterial.COAL,"coal", EquipmentSlotType.CHEST, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item coal_leggings = new ItemMoreArmor("coal_leggings", PattysArmorMaterial.COAL,"coal", EquipmentSlotType.LEGS, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item coal_boots  = new ItemMoreArmor("coal_boots", PattysArmorMaterial.COAL,"coal", EquipmentSlotType.FEET, new Item.Properties().group(ModTabs.tabPattysCombat));

    public static Item quartz_pickaxe = new ItemCustomPickaxe("quartz_pickaxe", PattysToolMaterial.QUARTZ,1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item quartz_axe = new ItemCustomAxe("quartz_axe", PattysToolMaterial.QUARTZ,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item quartz_shovel = new ItemCustomSpade("quartz_shovel", PattysToolMaterial.QUARTZ, 1.5F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item quartz_sword = new ItemCustomSword("quartz_sword", PattysToolMaterial.QUARTZ, 3, -2.4F, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item quartz_hoe = new ItemCustomHoe("quartz_hoe", PattysToolMaterial.QUARTZ, -3, 0.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item quartz_paxel = new ItemPaxel("quartz_paxel", PattysToolMaterial.QUARTZ_PAXEL, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item quartz_battle_axe = new ItemBattleaxe("quartz_battle_axe", PattysToolMaterial.QUARTZ,3, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item quartz_bow = new ItemCustomBow("quartz_bow", new Item.Properties().group(ModTabs.tabPattysCombat).defaultMaxDamage(PattysToolMaterial.QUARTZ.getMaxUses()));
    public static Item quartz_scythe = new ItemCustomScythe("quartz_scythe", new Item.Properties().group(ModTabs.tabPattysTools).defaultMaxDamage(PattysToolMaterial.QUARTZ.getMaxUses()));
    public static Item quartz_hammer = new ItemCustomHammer("quartz_hammer", PattysToolMaterial.QUARTZ, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item quartz_lumber_axe = new ItemLumberAxe("quartz_lumber_axe", PattysToolMaterial.QUARTZ,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item quartz_excavator = new ItemExcavator("quartz_excavator", PattysToolMaterial.QUARTZ,1, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));

    public static Item quartz_helmet = new ItemMoreArmor("quartz_helmet", PattysArmorMaterial.QUARTZ,"quartz", EquipmentSlotType.HEAD, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item quartz_chestplate = new ItemMoreArmor("quartz_chestplate", PattysArmorMaterial.QUARTZ,"quartz", EquipmentSlotType.CHEST, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item quartz_leggings = new ItemMoreArmor("quartz_leggings", PattysArmorMaterial.QUARTZ,"quartz", EquipmentSlotType.LEGS, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item quartz_boots = new ItemMoreArmor("quartz_boots", PattysArmorMaterial.QUARTZ,"quartz", EquipmentSlotType.FEET, new Item.Properties().group(ModTabs.tabPattysCombat));

    public static Item glowstone_pickaxe = new ItemCustomPickaxe("glowstone_pickaxe", PattysToolMaterial.GLOWSTONE,1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item glowstone_axe = new ItemCustomAxe("glowstone_axe", PattysToolMaterial.GLOWSTONE,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item glowstone_shovel = new ItemCustomSpade("glowstone_shovel", PattysToolMaterial.GLOWSTONE, 1.5F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item glowstone_sword = new ItemCustomSword("glowstone_sword", PattysToolMaterial.GLOWSTONE, 3, -2.4F, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item glowstone_hoe = new ItemCustomHoe("glowstone_hoe", PattysToolMaterial.GLOWSTONE, -3, 0.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item glowstone_paxel = new ItemPaxel("glowstone_paxel", PattysToolMaterial.GLOWSTONE_PAXEL, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item glowstone_battle_axe = new ItemBattleaxe("glowstone_battle_axe", PattysToolMaterial.GLOWSTONE,3, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item glowstone_bow = new ItemCustomBow("glowstone_bow", new Item.Properties().group(ModTabs.tabPattysCombat).defaultMaxDamage(PattysToolMaterial.GLOWSTONE.getMaxUses()));
    public static Item glowstone_scythe = new ItemCustomScythe("glowstone_scythe", new Item.Properties().group(ModTabs.tabPattysTools).defaultMaxDamage(PattysToolMaterial.GLOWSTONE.getMaxUses()));
    public static Item glowstone_hammer = new ItemCustomHammer("glowstone_hammer", PattysToolMaterial.GLOWSTONE, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item glowstone_lumber_axe = new ItemLumberAxe("glowstone_lumber_axe", PattysToolMaterial.GLOWSTONE,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item glowstone_excavator = new ItemExcavator("glowstone_excavator", PattysToolMaterial.GLOWSTONE,1, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));

    public static Item glowstone_helmet = new ItemMoreArmor("glowstone_helmet", PattysArmorMaterial.GLOWSTONE,"glowstone", EquipmentSlotType.HEAD, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item glowstone_chestplate = new ItemMoreArmor("glowstone_chestplate", PattysArmorMaterial.GLOWSTONE,"glowstone", EquipmentSlotType.CHEST, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item glowstone_leggings = new ItemMoreArmor("glowstone_leggings", PattysArmorMaterial.GLOWSTONE,"glowstone", EquipmentSlotType.LEGS, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item glowstone_boots = new ItemMoreArmor("glowstone_boots", PattysArmorMaterial.GLOWSTONE,"glowstone", EquipmentSlotType.FEET, new Item.Properties().group(ModTabs.tabPattysCombat));

    public static Item brick_pickaxe = new ItemCustomPickaxe("brick_pickaxe", PattysToolMaterial.BRICK,1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item brick_axe = new ItemCustomAxe("brick_axe", PattysToolMaterial.BRICK,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item brick_shovel = new ItemCustomSpade("brick_shovel", PattysToolMaterial.BRICK, 1.5F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item brick_hoe = new ItemCustomHoe("brick_hoe", PattysToolMaterial.BRICK, -3, 0.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item brick_sword = new ItemCustomSword("brick_sword", PattysToolMaterial.BRICK, 3, -2.4F, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item brick_paxel = new ItemPaxel("brick_paxel", PattysToolMaterial.BRICK_PAXEL, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item brick_battle_axe = new ItemBattleaxe("brick_battle_axe", PattysToolMaterial.BRICK,3, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item brick_bow = new ItemCustomBow("brick_bow", new Item.Properties().group(ModTabs.tabPattysCombat).defaultMaxDamage(PattysToolMaterial.BRICK.getMaxUses()));
    public static Item brick_scythe = new ItemCustomScythe("brick_scythe", new Item.Properties().group(ModTabs.tabPattysTools).defaultMaxDamage(PattysToolMaterial.BRICK.getMaxUses()));
    public static Item brick_hammer = new ItemCustomHammer("brick_hammer", PattysToolMaterial.BRICK, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item brick_lumber_axe = new ItemLumberAxe("brick_lumber_axe", PattysToolMaterial.BRICK,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item brick_excavator = new ItemExcavator("brick_excavator", PattysToolMaterial.BRICK,1, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));

    public static Item brick_helmet = new ItemMoreArmor("brick_helmet", PattysArmorMaterial.BRICK,"brick", EquipmentSlotType.HEAD, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item brick_chestplate = new ItemMoreArmor("brick_chestplate", PattysArmorMaterial.BRICK,"brick", EquipmentSlotType.CHEST, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item brick_leggings = new ItemMoreArmor("brick_leggings", PattysArmorMaterial.BRICK,"brick", EquipmentSlotType.LEGS, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item brick_boots = new ItemMoreArmor("brick_boots", PattysArmorMaterial.BRICK,"brick", EquipmentSlotType.FEET, new Item.Properties().group(ModTabs.tabPattysCombat));

    public static Item nbrick_pickaxe = new ItemCustomPickaxe("nbrick_pickaxe", PattysToolMaterial.NBRICK,1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item nbrick_axe = new ItemCustomAxe("nbrick_axe", PattysToolMaterial.NBRICK,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item nbrick_shovel = new ItemCustomSpade("nbrick_shovel", PattysToolMaterial.NBRICK, 1.5F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item nbrick_hoe = new ItemCustomHoe("nbrick_hoe", PattysToolMaterial.NBRICK, -3, 0.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item nbrick_sword = new ItemCustomSword("nbrick_sword", PattysToolMaterial.NBRICK, 3, -2.4F, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item nbrick_paxel = new ItemPaxel("nbrick_paxel", PattysToolMaterial.NBRICK_PAXEL, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item netherbrick_battle_axe = new ItemBattleaxe("netherbrick_battle_axe", PattysToolMaterial.NBRICK,3, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item netherbrick_bow = new ItemCustomBow("netherbrick_bow", new Item.Properties().group(ModTabs.tabPattysCombat).defaultMaxDamage(PattysToolMaterial.NBRICK.getMaxUses()));
    public static Item nbrick_scythe = new ItemCustomScythe("nbrick_scythe", new Item.Properties().group(ModTabs.tabPattysTools).defaultMaxDamage(PattysToolMaterial.NBRICK.getMaxUses()));
    public static Item nbrick_hammer = new ItemCustomHammer("nbrick_hammer", PattysToolMaterial.NBRICK, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item nbrick_lumber_axe = new ItemLumberAxe("nbrick_lumber_axe", PattysToolMaterial.NBRICK,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item nbrick_excavator = new ItemExcavator("nbrick_excavator", PattysToolMaterial.NBRICK,1, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));

    public static Item nether_brick_helmet = new ItemMoreArmor("nether_brick_helmet", PattysArmorMaterial.NETHER_BRICK,"nether_brick", EquipmentSlotType.HEAD, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item nether_brick_chestplate = new ItemMoreArmor("nether_brick_chestplate", PattysArmorMaterial.NETHER_BRICK,"nether_brick", EquipmentSlotType.CHEST, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item nether_brick_leggings = new ItemMoreArmor("nether_brick_leggings", PattysArmorMaterial.NETHER_BRICK,"nether_brick", EquipmentSlotType.LEGS, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item nether_brick_boots = new ItemMoreArmor("nether_brick_boots", PattysArmorMaterial.NETHER_BRICK,"nether_brick", EquipmentSlotType.FEET, new Item.Properties().group(ModTabs.tabPattysCombat));

    public static Item redstone_pickaxe = new ItemCustomPickaxe("redstone_pickaxe", PattysToolMaterial.REDSTONE,1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item redstone_axe = new ItemCustomAxe("redstone_axe", PattysToolMaterial.REDSTONE,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item redstone_shovel = new ItemCustomSpade("redstone_shovel", PattysToolMaterial.REDSTONE, 1.5F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item redstone_hoe = new ItemCustomHoe("redstone_hoe", PattysToolMaterial.REDSTONE, -3, 0.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item redstone_sword = new ItemCustomSword("redstone_sword", PattysToolMaterial.REDSTONE, 3, -2.4F, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item redstone_paxel = new ItemPaxel("redstone_paxel", PattysToolMaterial.REDSTONE_PAXEL, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item redstone_battle_axe = new ItemBattleaxe("redstone_battle_axe", PattysToolMaterial.REDSTONE,3, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item redstone_bow = new ItemCustomBow("redstone_bow", new Item.Properties().group(ModTabs.tabPattysCombat).defaultMaxDamage(PattysToolMaterial.REDSTONE.getMaxUses()));
    public static Item redstone_scythe = new ItemCustomScythe("redstone_scythe", new Item.Properties().group(ModTabs.tabPattysTools).defaultMaxDamage(PattysToolMaterial.REDSTONE.getMaxUses()));
    public static Item redstone_hammer = new ItemCustomHammer("redstone_hammer", PattysToolMaterial.REDSTONE, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item redstone_lumber_axe = new ItemLumberAxe("redstone_lumber_axe", PattysToolMaterial.REDSTONE,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item redstone_excavator = new ItemExcavator("redstone_excavator", PattysToolMaterial.REDSTONE,1, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));

    public static Item redstone_helmet = new ItemMoreArmor("redstone_helmet", PattysArmorMaterial.REDSTONE,"redstone", EquipmentSlotType.HEAD, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item redstone_chestplate = new ItemMoreArmor("redstone_chestplate", PattysArmorMaterial.REDSTONE,"redstone", EquipmentSlotType.CHEST, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item redstone_leggings = new ItemMoreArmor("redstone_leggings", PattysArmorMaterial.REDSTONE,"redstone", EquipmentSlotType.LEGS, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item redstone_boots = new ItemMoreArmor("redstone_boots", PattysArmorMaterial.REDSTONE,"redstone", EquipmentSlotType.FEET, new Item.Properties().group(ModTabs.tabPattysCombat));

    public static Item blaze_pickaxe = new ItemCustomPickaxe("blaze_pickaxe", PattysToolMaterial.BLAZE,1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item blaze_axe = new ItemCustomAxe("blaze_axe", PattysToolMaterial.BLAZE,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item blaze_shovel = new ItemCustomSpade("blaze_shovel", PattysToolMaterial.BLAZE, 1.5F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item blaze_hoe = new ItemCustomHoe("blaze_hoe", PattysToolMaterial.BLAZE, -3, 0.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item blaze_sword = new ItemCustomSword("blaze_sword", PattysToolMaterial.BLAZE, 3, -2.4F, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item blaze_paxel = new ItemPaxel("blaze_paxel", PattysToolMaterial.BLAZE_PAXEL, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item blaze_battle_axe = new ItemBattleaxe("blaze_battle_axe", PattysToolMaterial.BLAZE,3, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item blaze_bow = new ItemCustomBow("blaze_bow", new Item.Properties().group(ModTabs.tabPattysCombat).defaultMaxDamage(PattysToolMaterial.BLAZE.getMaxUses()));
    public static Item blaze_scythe = new ItemCustomScythe("blaze_scythe", new Item.Properties().group(ModTabs.tabPattysTools).defaultMaxDamage(PattysToolMaterial.BLAZE.getMaxUses()));
    public static Item blaze_hammer = new ItemCustomHammer("blaze_hammer", PattysToolMaterial.BLAZE, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item blaze_lumber_axe = new ItemLumberAxe("blaze_lumber_axe", PattysToolMaterial.BLAZE,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item blaze_excavator = new ItemExcavator("blaze_excavator", PattysToolMaterial.BLAZE,1, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));

    public static Item blaze_helmet = new ItemMoreArmor("blaze_helmet", PattysArmorMaterial.BLAZE,"blaze", EquipmentSlotType.HEAD, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item blaze_chestplate = new ItemMoreArmor("blaze_chestplate", PattysArmorMaterial.BLAZE,"blaze", EquipmentSlotType.CHEST, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item blaze_leggings = new ItemMoreArmor("blaze_leggings", PattysArmorMaterial.BLAZE,"blaze", EquipmentSlotType.LEGS, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item blaze_boots = new ItemMoreArmor("blaze_boots", PattysArmorMaterial.BLAZE,"blaze", EquipmentSlotType.FEET, new Item.Properties().group(ModTabs.tabPattysCombat));

    public static Item magma_cream_pickaxe = new ItemCustomPickaxe("magma_cream_pickaxe", PattysToolMaterial.MAGMACREAM,1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item magma_cream_axe = new ItemCustomAxe("magma_cream_axe", PattysToolMaterial.MAGMACREAM,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item magma_cream_shovel = new ItemCustomSpade("magma_cream_shovel", PattysToolMaterial.MAGMACREAM, 1.5F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item magma_cream_hoe = new ItemCustomHoe("magma_cream_hoe", PattysToolMaterial.MAGMACREAM, -3, 0.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item magma_cream_sword = new ItemCustomSword("magma_cream_sword", PattysToolMaterial.MAGMACREAM, 3, -2.4F, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item magma_cream_paxel = new ItemPaxel("magma_cream_paxel", PattysToolMaterial.MAGMACREAM_PAXEL, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item magmacream_battle_axe = new ItemBattleaxe("magmacream_battle_axe", PattysToolMaterial.MAGMACREAM,3, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item magma_cream_bow = new ItemCustomBow("magma_cream_bow", new Item.Properties().group(ModTabs.tabPattysCombat).defaultMaxDamage(PattysToolMaterial.MAGMACREAM.getMaxUses()));
    public static Item magma_cream_scythe = new ItemCustomScythe("magma_cream_scythe", new Item.Properties().group(ModTabs.tabPattysTools).defaultMaxDamage(PattysToolMaterial.MAGMACREAM.getMaxUses()));
    public static Item magma_cream_hammer = new ItemCustomHammer("magma_cream_hammer", PattysToolMaterial.MAGMACREAM, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item magma_cream_lumber_axe = new ItemLumberAxe("magma_cream_lumber_axe", PattysToolMaterial.MAGMACREAM,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item magma_cream_excavator = new ItemExcavator("magma_cream_excavator", PattysToolMaterial.MAGMACREAM,1, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));

    public static Item magma_cream_helmet = new ItemMoreArmor("magma_cream_helmet", PattysArmorMaterial.MAGMA_CREAM,"magma_cream", EquipmentSlotType.HEAD, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item magma_cream_chestplate = new ItemMoreArmor("magma_cream_chestplate", PattysArmorMaterial.MAGMA_CREAM,"magma_cream", EquipmentSlotType.CHEST, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item magma_cream_leggings = new ItemMoreArmor("magma_cream_leggings", PattysArmorMaterial.MAGMA_CREAM,"magma_cream", EquipmentSlotType.LEGS, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item magma_cream_boots = new ItemMoreArmor("magma_cream_boots", PattysArmorMaterial.MAGMA_CREAM,"magma_cream", EquipmentSlotType.FEET, new Item.Properties().group(ModTabs.tabPattysCombat));

    public static Item sandstone_pickaxe = new ItemCustomPickaxe("sandstone_pickaxe", PattysToolMaterial.SANDSTONE,1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item sandstone_axe = new ItemCustomAxe("sandstone_axe", PattysToolMaterial.SANDSTONE,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item sandstone_shovel = new ItemCustomSpade("sandstone_shovel", PattysToolMaterial.SANDSTONE, 1.5F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item sandstone_hoe = new ItemCustomHoe("sandstone_hoe", PattysToolMaterial.SANDSTONE, -3, 0.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item sandstone_sword = new ItemCustomSword("sandstone_sword", PattysToolMaterial.SANDSTONE, 3, -2.4F, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item sandstone_paxel = new ItemPaxel("sandstone_paxel", PattysToolMaterial.SANDSTONE_PAXEL, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item sandstone_battle_axe = new ItemBattleaxe("sandstone_battle_axe", PattysToolMaterial.SANDSTONE,3, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item sandstone_bow = new ItemCustomBow("sandstone_bow", new Item.Properties().group(ModTabs.tabPattysCombat).defaultMaxDamage(PattysToolMaterial.SANDSTONE.getMaxUses()));
    public static Item sandstone_scythe = new ItemCustomScythe("sandstone_scythe", new Item.Properties().group(ModTabs.tabPattysTools).defaultMaxDamage(PattysToolMaterial.SANDSTONE.getMaxUses()));
    public static Item sandstone_hammer = new ItemCustomHammer("sandstone_hammer", PattysToolMaterial.SANDSTONE, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item sandstone_lumber_axe = new ItemLumberAxe("sandstone_lumber_axe", PattysToolMaterial.SANDSTONE,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));

    public static Item sandstone_helmet = new ItemMoreArmor("sandstone_helmet", PattysArmorMaterial.SANDSTONE,"sandstone", EquipmentSlotType.HEAD, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item sandstone_chestplate = new ItemMoreArmor("sandstone_chestplate", PattysArmorMaterial.SANDSTONE,"sandstone", EquipmentSlotType.CHEST, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item sandstone_leggings = new ItemMoreArmor("sandstone_leggings", PattysArmorMaterial.SANDSTONE,"sandstone", EquipmentSlotType.LEGS, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item sandstone_boots = new ItemMoreArmor("sandstone_boots", PattysArmorMaterial.SANDSTONE,"sandstone", EquipmentSlotType.FEET, new Item.Properties().group(ModTabs.tabPattysCombat));

    public static Item soul_sand_pickaxe = new ItemCustomPickaxe("soul_sand_pickaxe", PattysToolMaterial.SOULSAND,1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item soul_sand_axe = new ItemCustomAxe("soul_sand_axe", PattysToolMaterial.SOULSAND,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item soul_sand_shovel = new ItemCustomSpade("soul_sand_shovel", PattysToolMaterial.SOULSAND, 1.5F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item soul_sand_hoe = new ItemCustomHoe("soul_sand_hoe", PattysToolMaterial.SOULSAND, -3, 0.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item soul_sand_sword = new ItemCustomSword("soul_sand_sword", PattysToolMaterial.SOULSAND, 3, -2.4F, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item soul_sand_paxel = new ItemPaxel("soul_sand_paxel", PattysToolMaterial.SOULSAND_PAXEL, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item soulsand_battle_axe = new ItemBattleaxe("soulsand_battle_axe", PattysToolMaterial.SOULSAND,3, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item soul_sand_bow = new ItemCustomBow("soul_sand_bow", new Item.Properties().group(ModTabs.tabPattysCombat).defaultMaxDamage(PattysToolMaterial.SOULSAND.getMaxUses()));
    public static Item soul_sand_scythe = new ItemCustomScythe("soul_sand_scythe", new Item.Properties().group(ModTabs.tabPattysTools).defaultMaxDamage(PattysToolMaterial.SOULSAND.getMaxUses()));
    public static Item soul_sand_hammer = new ItemCustomHammer("soul_sand_hammer", PattysToolMaterial.SOULSAND, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item soul_sand_lumber_axe = new ItemLumberAxe("soul_sand_lumber_axe", PattysToolMaterial.SOULSAND,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));

    public static Item soul_sand_helmet = new ItemMoreArmor("soul_sand_helmet", PattysArmorMaterial.SOUL_SAND,"soul_sand", EquipmentSlotType.HEAD, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item soul_sand_chestplate = new ItemMoreArmor("soul_sand_chestplate", PattysArmorMaterial.SOUL_SAND,"soul_sand", EquipmentSlotType.CHEST, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item soul_sand_leggings = new ItemMoreArmor("soul_sand_leggings", PattysArmorMaterial.SOUL_SAND,"soul_sand", EquipmentSlotType.LEGS, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item soul_sand_boots = new ItemMoreArmor("soul_sand_boots", PattysArmorMaterial.SOUL_SAND,"soul_sand", EquipmentSlotType.FEET, new Item.Properties().group(ModTabs.tabPattysCombat));

    public static Item netherbrickred_pickaxe = new ItemCustomPickaxe("netherbrickred_pickaxe", PattysToolMaterial.NETHERBRICKRED,1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item netherbrickred_axe = new ItemCustomAxe("netherbrickred_axe", PattysToolMaterial.NETHERBRICKRED,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item netherbrickred_shovel = new ItemCustomSpade("netherbrickred_shovel", PattysToolMaterial.NETHERBRICKRED, 1.5F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item netherbrickred_hoe = new ItemCustomHoe("netherbrickred_hoe", PattysToolMaterial.NETHERBRICKRED, -3, 0.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item netherbrickred_sword = new ItemCustomSword("netherbrickred_sword", PattysToolMaterial.NETHERBRICKRED, 3, -2.4F, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item netherbrickred_paxel = new ItemPaxel("netherbrickred_paxel", PattysToolMaterial.NETHERBRICKRED_PAXEL, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item netherbrickred_battle_axe = new ItemBattleaxe("netherbrickred_battle_axe", PattysToolMaterial.NETHERBRICKRED,3, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item netherbrickred_bow = new ItemCustomBow("netherbrickred_bow", new Item.Properties().group(ModTabs.tabPattysCombat).defaultMaxDamage(PattysToolMaterial.NETHERBRICKRED.getMaxUses()));
    public static Item netherbrickred_scythe = new ItemCustomScythe("netherbrickred_scythe", new Item.Properties().group(ModTabs.tabPattysTools).defaultMaxDamage(PattysToolMaterial.NETHERBRICKRED.getMaxUses()));
    public static Item netherbrickred_hammer = new ItemCustomHammer("netherbrickred_hammer", PattysToolMaterial.NETHERBRICKRED, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item netherbrickred_lumber_axe = new ItemLumberAxe("netherbrickred_lumber_axe", PattysToolMaterial.NETHERBRICKRED,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));

    public static Item red_netherbrick_helmet = new ItemMoreArmor("red_netherbrick_helmet", PattysArmorMaterial.RED_NETHER_BRICK,"red_nether_brick", EquipmentSlotType.HEAD, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item red_netherbrick_chestplate = new ItemMoreArmor("red_netherbrick_chestplate", PattysArmorMaterial.RED_NETHER_BRICK,"red_nether_brick", EquipmentSlotType.CHEST, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item red_netherbrick_leggings = new ItemMoreArmor("red_netherbrick_leggings", PattysArmorMaterial.RED_NETHER_BRICK,"red_nether_brick", EquipmentSlotType.LEGS, new Item.Properties().group(ModTabs.tabPattysCombat));
    public static Item red_netherbrick_boots = new ItemMoreArmor("red_netherbrick_boots", PattysArmorMaterial.RED_NETHER_BRICK,"red_nether_brick", EquipmentSlotType.FEET, new Item.Properties().group(ModTabs.tabPattysCombat));

    public static Item wooden_paxel = new ItemPaxel("wooden_paxel", PattysToolMaterial.WOOD_PAXEL, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item wooden_battle_axe = new ItemBattleaxe("wooden_battle_axe", ItemTier.WOOD,3, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item wood_scythe = new ItemCustomScythe("wood_scythe", new Item.Properties().group(ModTabs.tabPattysTools).defaultMaxDamage(ItemTier.WOOD.getMaxUses()));
    public static Item wooden_hammer = new ItemCustomHammer("wooden_hammer", ItemTier.WOOD, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item wooden_lumber_axe = new ItemLumberAxe("wooden_lumber_axe", ItemTier.WOOD,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));

    public static Item stone_paxel = new ItemPaxel("stone_paxel", PattysToolMaterial.STONE_PAXEL, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item stone_battle_axe = new ItemBattleaxe("stone_battle_axe", ItemTier.STONE,3, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item stone_bow = new ItemCustomBow("stone_bow", new Item.Properties().group(ModTabs.tabPattysCombat).defaultMaxDamage(ItemTier.STONE.getMaxUses()));
    public static Item stone_scythe = new ItemCustomScythe("stone_scythe", new Item.Properties().group(ModTabs.tabPattysTools).defaultMaxDamage(ItemTier.STONE.getMaxUses()));
    public static Item stone_hammer = new ItemCustomHammer("stone_hammer", ItemTier.STONE, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item stone_lumber_axe = new ItemLumberAxe("stone_lumber_axe", ItemTier.STONE,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));

    public static Item iron_paxel = new ItemPaxel("iron_paxel", PattysToolMaterial.IRON_PAXEL, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item iron_battle_axe = new ItemBattleaxe("iron_battle_axe", ItemTier.IRON,3, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item iron_bow = new ItemCustomBow("iron_bow", new Item.Properties().group(ModTabs.tabPattysCombat).defaultMaxDamage(ItemTier.IRON.getMaxUses()));
    public static Item iron_scythe = new ItemCustomScythe("iron_scythe", new Item.Properties().group(ModTabs.tabPattysTools).defaultMaxDamage(ItemTier.IRON.getMaxUses()));
    public static Item iron_hammer = new ItemCustomHammer("iron_hammer", ItemTier.IRON, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item iron_lumber_axe = new ItemLumberAxe("iron_lumber_axe", ItemTier.IRON,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item iron_excavator = new ItemExcavator("iron_excavator", ItemTier.IRON,1, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));

    public static Item gold_paxel = new ItemPaxel("gold_paxel", PattysToolMaterial.GOLD_PAXEL, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item gold_battle_axe = new ItemBattleaxe("gold_battle_axe", ItemTier.GOLD,3, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item gold_bow = new ItemCustomBow("gold_bow", new Item.Properties().group(ModTabs.tabPattysCombat).defaultMaxDamage(ItemTier.GOLD.getMaxUses()));
    public static Item gold_scythe = new ItemCustomScythe("gold_scythe", new Item.Properties().group(ModTabs.tabPattysTools).defaultMaxDamage(ItemTier.GOLD.getMaxUses()));
    public static Item gold_hammer = new ItemCustomHammer("gold_hammer", ItemTier.GOLD, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item gold_lumber_axe = new ItemLumberAxe("gold_lumber_axe", ItemTier.GOLD,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item gold_excavator = new ItemExcavator("gold_excavator", ItemTier.GOLD,1, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));

    public static Item diamond_paxel = new ItemPaxel("diamond_paxel", PattysToolMaterial.DIAMOND_PAXEL, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item diamond_battle_axe = new ItemBattleaxe("diamond_battle_axe", ItemTier.DIAMOND,3, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item diamond_bow = new ItemCustomBow("diamond_bow", new Item.Properties().group(ModTabs.tabPattysCombat).defaultMaxDamage(ItemTier.DIAMOND.getMaxUses()));
    public static Item diamond_scythe = new ItemCustomScythe("diamond_scythe", new Item.Properties().group(ModTabs.tabPattysTools).defaultMaxDamage(ItemTier.DIAMOND.getMaxUses()));
    public static Item diamond_hammer = new ItemCustomHammer("diamond_hammer", ItemTier.DIAMOND, 1, -2.8F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item diamond_lumber_axe = new ItemLumberAxe("diamond_lumber_axe", ItemTier.DIAMOND,5.0F, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));
    public static Item diamond_excavator = new ItemExcavator("diamond_excavator", ItemTier.DIAMOND,1, -3.0F, new Item.Properties().group(ModTabs.tabPattysTools));

    public static Item fried_egg = new ItemCustomFood("fried_egg", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.FRIED_EGG));
    public static Item bacon_raw = new ItemCustomFood("bacon_raw", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.BACON_RAW));
    public static Item bacon_cooked = new ItemCustomFood("bacon_cooked", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.BACON_COOKED));
    public static Item sausage_raw = new ItemCustomFood("sausage_raw", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.SAUSAGE_RAW));
    public static Item sausage_cooked = new ItemCustomFood("sausage_cooked", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.SAUSAGE_COOKED));
    public static Item baguette_roll = new ItemCustomFood("baguette_roll", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.BAGUETTE_ROLL));
    public static Item baguette_bacon = new ItemCustomFood("baguette_bacon", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.BAGUETTE_BACON));
    public static Item baguette_egg = new ItemCustomFood("baguette_egg", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.BAGUETTE_EGG));
    public static Item baguette_eggbacon = new ItemCustomFood("baguette_eggbacon", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.BAGUETTE_EGGBACON));
    public static Item baguette_sausage = new ItemCustomFood("baguette_sausage", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.BAGUETTE_SAUSAGE));
    public static Item baguette_baconsausage = new ItemCustomFood("baguette_baconsausage", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.BAGUETTE_BACONSAUSAGE));
    public static Item baguette_eggsausage = new ItemCustomFood("baguette_eggsausage", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.BAGUETTE_EGGSAUSAGE));
    public static Item baguette_eggbaconsausage = new ItemCustomFood("baguette_eggbaconsausage", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.BAGUETTE_EGGBACONSAUSAGE));
    public static Item apple_pie = new ItemCustomFood("apple_pie", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.APPLE_PIE));
    public static Item toast = new ItemCustomFood("toast", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.TOAST));
    public static Item flour = new ItemBase("flour", new Item.Properties().group(ModTabs.tabPattysFood));
    public static Item fruit_salad = new ItemCustomFood("fruit_salad", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.FRUIT_SALAD));
    public static Item double_choc_cookie = new ItemCustomFood("double_choc_cookie", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.DOUBLE_CHOC_COOKIE));

    public static Item apple_juice = new ItemDrinkable("apple_juice", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.APPLE_JUICE));
    public static Item melon_juice = new ItemDrinkable("melon_juice", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.MELON_JUICE));
    public static Item carrot_juice = new ItemDrinkable("carrot_juice", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.CARROT_JUICE));
    public static Item beetroot_juice = new ItemDrinkable("beetroot_juice", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.BEETROOT_JUICE));
    public static Item pumpkin_juice = new ItemDrinkable("pumpkin_juice", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.PUMPKIN_JUICE));
    public static Item bottle_milk = new ItemMilkBottle("bottle_milk", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.MILK_BOTTLE));
    public static Item bottle_chocolate_milk = new ItemChocolateMilk("bottle_chocolate_milk", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.CHOCOLATE_MILK_BOTTLE));

    public static Item apple_slushie = new ItemDrinkable("apple_slushie", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.APPLE_SLUSHIE));
    public static Item melon_slushie = new ItemDrinkable("melon_slushie", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.MELON_SLUSHIE));
    public static Item carrot_slushie = new ItemDrinkable("carrot_slushie", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.CARROT_SLUSHIE));
    public static Item beetroot_slushie = new ItemDrinkable("beetroot_slushie", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.BEETROOT_SLUSHIE));
    public static Item pumpkin_slushie = new ItemDrinkable("pumpkin_slushie", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.PUMPKIN_SLUSHIE));

    public static Item apple_smoothie = new ItemDrinkable("apple_smoothie", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.APPLE_SMOOTHIE));
    public static Item melon_smoothie = new ItemDrinkable("melon_smoothie", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.MELON_SMOOTHIE));
    public static Item carrot_smoothie = new ItemDrinkable("carrot_smoothie", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.CARROT_SMOOTHIE));
    public static Item beetroot_smoothie = new ItemDrinkable("beetroot_smoothie", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.BEETROOT_SMOOTHIE));
    public static Item pumpkin_smoothie = new ItemDrinkable("pumpkin_smoothie", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.PUMPKIN_SMOOTHIE));

    public static Item miners_helmet = new ItemMoreArmor("miners_helmet", PattysArmorMaterial.MINER, "miner", EquipmentSlotType.HEAD, new Item.Properties().group(ModTabs.tabPattysMisc));
    public static Item magnet = new ItemMagnet("magnet", new Item.Properties().group(ModTabs.tabPattysMisc));
    public static Item ring_of_flight = new ItemFlightRing("ring_of_flight", new Item.Properties().group(ModTabs.tabPattysMisc));
    public static Item sweet_berrie_pie = new ItemCustomFood("sweet_berrie_pie", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.SWEET_BERRIE_PIE));
    public static Item bacon_egg = new ItemCustomFood("bacon_egg", new Item.Properties().group(ModTabs.tabPattysFood).food(PattysFoods.BACON_EGG));

    public static Item white_backpack = new ItemBackpack("white_backpack");
    public static Item orange_backpack = new ItemBackpack("orange_backpack");
    public static Item magenta_backpack = new ItemBackpack("magenta_backpack");
    public static Item light_blue_backpack = new ItemBackpack("light_blue_backpack");
    public static Item yellow_backpack = new ItemBackpack("yellow_backpack");
    public static Item lime_backpack = new ItemBackpack("lime_backpack");
    public static Item pink_backpack = new ItemBackpack("pink_backpack");
    public static Item light_gray_backpack = new ItemBackpack("light_gray_backpack");
    public static Item gray_backpack = new ItemBackpack("gray_backpack");
    public static Item cyan_backpack = new ItemBackpack("cyan_backpack");
    public static Item purple_backpack = new ItemBackpack("purple_backpack");
    public static Item blue_backpack = new ItemBackpack("blue_backpack");
    public static Item brown_backpack = new ItemBackpack("brown_backpack");
    public static Item green_backpack = new ItemBackpack("green_backpack");
    public static Item red_backpack = new ItemBackpack("red_backpack");
    public static Item black_backpack = new ItemBackpack("black_backpack");
    
}
