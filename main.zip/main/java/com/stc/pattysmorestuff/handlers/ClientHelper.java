package com.stc.pattysmorestuff.handlers;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;

public class ClientHelper {

    public static World getWorld()
    {
        return Minecraft.getInstance().world;
    }

    public static PlayerEntity getPlayer()
    {
        return Minecraft.getInstance().player;
    }
}
