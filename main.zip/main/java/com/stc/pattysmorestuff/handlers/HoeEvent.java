package com.stc.pattysmorestuff.handlers;

import com.stc.pattysmorestuff.blocks.BlockFertilizedDirt;
import com.stc.pattysmorestuff.init.ModBlocks;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemUseContext;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.player.UseHoeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.fml.common.Mod;

public class HoeEvent {

    /*public static void init() {

        MinecraftForge.EVENT_BUS.addListener((UseHoeEvent event) -> {
            ItemUseContext context = event.getContext();

            World world = context.getWorld();
            BlockPos pos = context.getPos();
            BlockState state = world.getBlockState(pos);

            if (state.getBlock() == ModBlocks.fertilized_dirt && !state.get(BlockFertilizedDirt.TILLED))
            {
                event.setResult(Event.Result.ALLOW);
                world.setBlockState(pos, state.with(BlockFertilizedDirt.TILLED, true));
                PlayerEntity playerentity = context.getPlayer();
                world.playSound(playerentity, pos, SoundEvents.ITEM_HOE_TILL, SoundCategory.BLOCKS, 1.0F, 1.0F);
            }
        });
    }*/
}
