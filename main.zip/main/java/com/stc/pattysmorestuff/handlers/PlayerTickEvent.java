package com.stc.pattysmorestuff.handlers;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.ImmutableSet;
import com.stc.pattysmorestuff.config.ConfigGeneral;
import com.stc.pattysmorestuff.init.ModItems;
import com.stc.pattysmorestuff.items.lumberaxe.ItemLumberAxe;
import com.stc.pattysmorestuff.items.lumberaxe.ItemNstarLumberAxe;
import com.stc.pattysmorestuff.items.wand.ItemTimeWand;
import net.minecraft.block.BlockState;
import net.minecraft.block.material.Material;
import net.minecraft.client.GameConfiguration;
import net.minecraft.client.GameSettings;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;

import java.util.UUID;

@Mod.EventBusSubscriber(Dist.CLIENT)
public class PlayerTickEvent {

    @SubscribeEvent
    public static void onTickPlayerEvent(TickEvent.PlayerTickEvent event) {

        if (event.player.inventory.hasItemStack(new ItemStack(ModItems.ring_of_flight))) {
            event.player.abilities.allowFlying = true;
        } else {
            if (event.player.abilities.isFlying == true && !event.player.inventory.hasItemStack(new ItemStack(ModItems.ring_of_flight)) && !event.player.isCreative() && !event.player.isSpectator()) {
                event.player.abilities.isFlying = false;
                event.player.abilities.allowFlying = false;
            }
        }
    }
}
