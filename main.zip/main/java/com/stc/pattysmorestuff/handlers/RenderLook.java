package com.stc.pattysmorestuff.handlers;

import com.stc.pattysmorestuff.init.ModBlocks;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.RenderTypeLookup;

public class RenderLook {

    public static void init() {
        RenderTypeLookup.setRenderLayer(ModBlocks.reinforced_glass, RenderType.getTranslucent());
        RenderTypeLookup.setRenderLayer(ModBlocks.slime_stairs, RenderType.getTranslucent());
        RenderTypeLookup.setRenderLayer(ModBlocks.honey_stairs, RenderType.getTranslucent());
        RenderTypeLookup.setRenderLayer(ModBlocks.wild_crop, RenderType.getCutout());

        RenderTypeLookup.setRenderLayer(ModBlocks.blender_white, RenderType.getTranslucent());
        RenderTypeLookup.setRenderLayer(ModBlocks.blender_orange, RenderType.getTranslucent());
        RenderTypeLookup.setRenderLayer(ModBlocks.blender_magenta, RenderType.getTranslucent());
        RenderTypeLookup.setRenderLayer(ModBlocks.blender_light_blue, RenderType.getTranslucent());
        RenderTypeLookup.setRenderLayer(ModBlocks.blender_yellow, RenderType.getTranslucent());
        RenderTypeLookup.setRenderLayer(ModBlocks.blender_pink, RenderType.getTranslucent());
        RenderTypeLookup.setRenderLayer(ModBlocks.blender_lime, RenderType.getTranslucent());
        RenderTypeLookup.setRenderLayer(ModBlocks.blender_silver, RenderType.getTranslucent());
        RenderTypeLookup.setRenderLayer(ModBlocks.blender_gray, RenderType.getTranslucent());
        RenderTypeLookup.setRenderLayer(ModBlocks.blender_cyan, RenderType.getTranslucent());
        RenderTypeLookup.setRenderLayer(ModBlocks.blender_purple, RenderType.getTranslucent());
        RenderTypeLookup.setRenderLayer(ModBlocks.blender_blue, RenderType.getTranslucent());
        RenderTypeLookup.setRenderLayer(ModBlocks.blender_brown, RenderType.getTranslucent());
        RenderTypeLookup.setRenderLayer(ModBlocks.blender_green, RenderType.getTranslucent());
        RenderTypeLookup.setRenderLayer(ModBlocks.blender_red, RenderType.getTranslucent());
        RenderTypeLookup.setRenderLayer(ModBlocks.blender_black, RenderType.getTranslucent());

        //RenderTypeLookup.setRenderLayer(ModBlocks.cookie_jar_red, RenderType.getTranslucent());
        //ClientRegistry.bindTileEntityRenderer(ModTileEntities.RED_JAR, RenderJarRed::new);

    }
}
