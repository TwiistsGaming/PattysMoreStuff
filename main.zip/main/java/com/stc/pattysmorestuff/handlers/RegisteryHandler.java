package com.stc.pattysmorestuff.handlers;

import com.stc.pattysmorestuff.blocks.crusher.CrusherContainer;
import com.stc.pattysmorestuff.init.ModBlocks;
import com.stc.pattysmorestuff.init.ModItems;
import com.stc.pattysmorestuff.items.backpack.BackpackContainer;
import com.stc.pattysmorestuff.tileentity.crates.containers.CrateContainer;
import net.minecraft.block.Block;
import net.minecraft.inventory.container.ContainerType;
import net.minecraft.item.Item;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(bus=Mod.EventBusSubscriber.Bus.MOD)
public class RegisteryHandler {

    @SubscribeEvent
    public static void onBlocksRegistry(final RegistryEvent.Register<Block> blockRegistryEvent) {

        blockRegistryEvent.getRegistry().registerAll(ModBlocks.BLOCKS.toArray(new Block[0]));

    }

    @SubscribeEvent
    public static void onItemRegister(final RegistryEvent.Register<Item> event) {

        event.getRegistry().registerAll(ModItems.ITEMS.toArray(new Item[0]));
    }

    @SubscribeEvent
    public static void onContainerRegistry(final RegistryEvent.Register<ContainerType<?>> event) {
        event.getRegistry().register(new ContainerType<>(CrateContainer::createGeneric9X6).setRegistryName("oak_storage_crate"));
        event.getRegistry().register(new ContainerType<>(CrateContainer::createGeneric9X6).setRegistryName("spruce_storage_crate"));
        event.getRegistry().register(new ContainerType<>(CrateContainer::createGeneric9X6).setRegistryName("birch_storage_crate"));
        event.getRegistry().register(new ContainerType<>(CrateContainer::createGeneric9X6).setRegistryName("jungle_storage_crate"));
        event.getRegistry().register(new ContainerType<>(CrateContainer::createGeneric9X6).setRegistryName("acacia_storage_crate"));
        event.getRegistry().register(new ContainerType<>(CrateContainer::createGeneric9X6).setRegistryName("big_oak_storage_crate"));
        event.getRegistry().register(new ContainerType<>(CrusherContainer::new).setRegistryName("crusher"));
        event.getRegistry().register(new ContainerType<>(BackpackContainer::new).setRegistryName("backpack"));

    }
}
