package com.stc.pattysmorestuff.handlers;

import com.stc.pattysmorestuff.init.ModItems;
import net.minecraft.block.Blocks;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.IArmorMaterial;
import net.minecraft.item.Items;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.util.LazyValue;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.SoundEvents;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.function.Supplier;

public enum PattysArmorMaterial implements IArmorMaterial {

    NSTAR("pattysmorestuff:nether_star", 45, new int[]{6, 9, 11, 7}, 10, SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND, 6.5F, () -> {
        return Ingredient.fromItems(Items.NETHER_STAR);
    }),
    EMERALD("pattysmorestuff:emerald", 28, new int[]{1, 2, 3, 1}, 7, SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND, 0F, () -> {
        return Ingredient.fromItems(Items.EMERALD);
    }),
    OBSIDIAN("pattysmorestuff:obsidian", 36, new int[]{2, 3, 2, 2}, 10, SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND, 0.0F, () -> {
        return Ingredient.fromItems(ModItems.obsidian_ingot);
    }),
    ENDER("pattysmorestuff:ender", 12, new int[]{1, 5, 6, 2}, 10, SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND, 0.0F, () -> {
        return Ingredient.fromItems(Items.ENDER_PEARL);
    }),
    MAGMA_CREAM("pattysmorestuff:megma_cream", 12, new int[]{1, 5, 6, 2}, 9, SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND, 0.0F, () -> {
        return Ingredient.fromItems(Items.MAGMA_CREAM);
    }),
    BLAZE("pattysmorestuff:blaze", 11, new int[]{1, 5, 6, 2}, 9, SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND, 0.0F, () -> {
        return Ingredient.fromItems(Items.BLAZE_POWDER);
    }),
    QUARTZ("pattysmorestuff:quartz", 11, new int[]{1, 4, 5, 2}, 9, SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND, 0.0F, () -> {
        return Ingredient.fromItems(Items.QUARTZ);
    }),
    GLOWSTONE("pattysmorestuff:glowstone", 11, new int[]{1, 4, 5, 2}, 9, SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND, 0.0F, () -> {
        return Ingredient.fromItems(Items.GLOWSTONE_DUST);
    }),
    REDSTONE("pattysmorestuff:redstone", 11, new int[]{1, 4, 5, 2}, 9, SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND, 0.0F, () -> {
        return Ingredient.fromItems(Items.REDSTONE);
    }),
    COAL("pattysmorestuff:coal", 10, new int[]{1, 3, 4, 2}, 12, SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND, 0.0F, () -> {
        return Ingredient.fromItems(Items.COAL);
    }),
    BRICK("pattysmorestuff:brick", 8, new int[]{1, 3, 3, 1}, 12, SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND, 0.0F, () -> {
        return Ingredient.fromItems(Items.BRICK);
    }),
    NETHER_BRICK("pattysmorestuff:nether_brick", 8, new int[]{1, 3, 3, 1}, 12, SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND, 0.0F, () -> {
        return Ingredient.fromItems(Items.NETHER_BRICK);
    }),
    RED_NETHER_BRICK("pattysmorestuff:red_nether_brick", 8, new int[]{1, 3, 3, 1}, 12, SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND, 0.0F, () -> {
        return Ingredient.fromItems(Blocks.RED_NETHER_BRICKS);
    }),
    SANDSTONE("pattysmorestuff:sandstone", 8, new int[]{1, 3, 3, 1}, 12, SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND, 0.0F, () -> {
        return Ingredient.fromItems(Blocks.SANDSTONE);
    }),
    SOUL_SAND("pattysmorestuff:soul_sand", 8, new int[]{1, 3, 3, 1}, 12, SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND, 0.0F, () -> {
        return Ingredient.fromItems(Blocks.SOUL_SAND);
    }),
    MINER("pattysmorestuff:miner", 15, new int[]{2, 5, 6, 2}, 9, SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND, 0.0F, () -> {
        return Ingredient.fromItems(Items.IRON_INGOT);
    });

    private static final int[] MAX_DAMAGE_ARRAY = new int[]{13, 15, 16, 11};
    private final String name;
    private final int maxDamageFactor;
    private final int[] damageReductionAmountArray;
    private final int enchantability;
    private final SoundEvent soundEvent;
    private final float toughness;
    private final LazyValue<Ingredient> repairMaterial;

    private PattysArmorMaterial(String nameIn, int maxDamageFactorIn, int[] damageReductionAmountsIn, int enchantabilityIn, SoundEvent equipSoundIn, float toughnessIn, Supplier<Ingredient> repairMaterialSupplier) {
        this.name = nameIn;
        this.maxDamageFactor = maxDamageFactorIn;
        this.damageReductionAmountArray = damageReductionAmountsIn;
        this.enchantability = enchantabilityIn;
        this.soundEvent = equipSoundIn;
        this.toughness = toughnessIn;
        this.repairMaterial = new LazyValue<>(repairMaterialSupplier);
    }

    public int getDurability(EquipmentSlotType slotIn) {
        return MAX_DAMAGE_ARRAY[slotIn.getIndex()] * this.maxDamageFactor;
    }

    public int getDamageReductionAmount(EquipmentSlotType slotIn) {
        return this.damageReductionAmountArray[slotIn.getIndex()];
    }

    public int getEnchantability() {
        return this.enchantability;
    }

    public SoundEvent getSoundEvent() {
        return this.soundEvent;
    }

    public Ingredient getRepairMaterial() {
        return this.repairMaterial.getValue();
    }

    @OnlyIn(Dist.CLIENT)
    public String getName() {
        return this.name;
    }

    public float getToughness() {
        return this.toughness;
    }

    @Override
    public float func_230304_f_() {
        return 0;
    }
}
