package com.stc.pattysmoretools.init;

import com.stc.pattysmoretools.config.ConfigGeneral;
import net.minecraft.item.*;

public class ModTabs {

    public static ItemGroup tabPattysMisc;
    public static ItemGroup tabPattysTools;
    public static ItemGroup tabPattysCombat;

    public static void pattysTabs() {

        tabPattysMisc = new ItemGroup(ItemGroup.getGroupCountSafe(), "Misc") {
            @Override
            public ItemStack createIcon() {
                return new ItemStack(ModItems.obsidian_ingot);
            }

            @Override
            public String getTranslationKey() {
                return "Pattys Misc";
            }
        };
        if(ConfigGeneral.disableTools.get()) {

            tabPattysTools = new ItemGroup(ItemGroup.getGroupCountSafe(), "Tools") {
                @Override
                public ItemStack createIcon() {
                    return new ItemStack(ModItems.obsidian_axe);
                }

                @Override
                public String getTranslationKey() {
                    return "Pattys Tools";
                }
            };
        }
        tabPattysCombat = new ItemGroup(ItemGroup.getGroupCountSafe(), "Combat") {
                @Override
                public ItemStack createIcon() {
                        return new ItemStack(ModItems.ender_sword);
                }

                @Override
                public String getTranslationKey() {
                        return "Pattys Combat";
                }
        };
    }
}
