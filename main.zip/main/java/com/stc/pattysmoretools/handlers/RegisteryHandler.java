package com.stc.pattysmoretools.handlers;

import com.stc.pattysmoretools.PattysMoreTools;
import com.stc.pattysmoretools.init.ModItems;
import net.minecraft.item.Item;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = PattysMoreTools.MODID, bus=Mod.EventBusSubscriber.Bus.MOD)
public class RegisteryHandler {

    @SubscribeEvent
    public static void onItemRegister(final RegistryEvent.Register<Item> event) {

        event.getRegistry().registerAll(ModItems.ITEMS.toArray(new Item[0]));

    }

}
