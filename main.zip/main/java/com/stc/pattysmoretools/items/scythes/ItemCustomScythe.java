package com.stc.pattysmoretools.items.scythes;


import net.minecraft.item.ItemStack;

public class ItemCustomScythe extends ItemNStarScythe {
    public ItemCustomScythe(String name, Properties properties) {
        super(name, properties);
    }

    @Override
    public boolean hasEffect(ItemStack stack) {
        return false;
    }
}
