package com.stc.pattysmoretools.items.scythes;

import com.stc.pattysmoretools.PattysMoreTools;
import com.stc.pattysmoretools.config.ConfigGeneral;
import com.stc.pattysmoretools.init.ModItems;
import net.minecraft.block.BlockState;
import net.minecraft.block.IGrowable;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUseContext;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.List;

public class ItemNStarScythe extends Item {
    public ItemNStarScythe(String name, Item.Properties properties) {
        super(properties);
        this.setRegistryName(PattysMoreTools.MODID, name);

        if(ConfigGeneral.disableScythes.get()) {

            ModItems.ITEMS.add(this);
        }
    }

    @Override
    public ActionResultType onItemUse(ItemUseContext useContext) {

        World world = useContext.getWorld();
        BlockPos pos = useContext.getPos();

        for(int i = -1; i < 2; ++i) {
            for (int j = -1; j < 2; ++j) {
                BlockPos bPos = new BlockPos(pos.add(i, 0, j));
                if (world.getBlockState(bPos).getBlock() instanceof IGrowable) {
                    IGrowable iG = (IGrowable) world.getBlockState(bPos).getBlock();
                    BlockState bState = world.getBlockState(bPos);
                    if (!iG.canGrow(world, bPos, bState, false)) {
                        world.destroyBlock(bPos, true);
                        world.setBlockState(bPos, bState.getBlock().getDefaultState());
                        useContext.getItem().setDamage(9);

                    }

                }
            }
        }
        return super.onItemUse(useContext);
    }

    @Override
    public void addInformation(ItemStack stack, @Nullable World worldIn, List<ITextComponent> tooltip, ITooltipFlag flagIn) {
        tooltip.add(new StringTextComponent(TextFormatting.GREEN  + "Harvests (and replants) a 3x3 of grown crops & flowers"));
    }

    @Override
    public boolean hasEffect(ItemStack stack) {
        return true;
    }
}
