package com.stc.pattysmoretools.items;

import com.stc.pattysmoretools.PattysMoreTools;
import com.stc.pattysmoretools.init.ModItems;
import net.minecraft.item.Item;

public class ItemBase extends Item {
    public ItemBase(String name, Properties properties) {
        super(properties);
        this.setRegistryName(PattysMoreTools.MODID, name);

        ModItems.ITEMS.add(this);
    }
}
