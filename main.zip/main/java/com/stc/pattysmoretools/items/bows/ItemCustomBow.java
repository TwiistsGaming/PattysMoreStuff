package com.stc.pattysmoretools.items.bows;

import net.minecraft.item.ItemStack;

public class ItemCustomBow extends ItemNstarBow {
    public ItemCustomBow(String name, Properties properties) {
        super(name, properties);
    }

    @Override
    public boolean hasEffect(ItemStack stack) {
        return false;
    }
}
