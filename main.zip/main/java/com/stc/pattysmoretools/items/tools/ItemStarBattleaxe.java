package com.stc.pattysmoretools.items.tools;

import com.google.common.collect.Multimap;
import com.stc.pattysmoretools.PattysMoreTools;
import com.stc.pattysmoretools.config.ConfigGeneral;
import com.stc.pattysmoretools.init.ModItems;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RotatedPillarBlock;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.*;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class ItemStarBattleaxe extends AxeItem {

    public ItemStarBattleaxe(String name, IItemTier material, Item.Properties builder) {
        super(material, 5.0F, -3.0F, builder);
        this.setRegistryName(PattysMoreTools.MODID, name);

        if(ConfigGeneral.disableTools.get()) {

            ModItems.ITEMS.add(this);
        }
    }

    /**
     * Called when this item is used when targetting a Block
     */
    public ActionResultType onItemUse(ItemUseContext p_195939_1_) {
        World world = p_195939_1_.getWorld();
        BlockPos blockpos = p_195939_1_.getPos();
        BlockState iblockstate = world.getBlockState(blockpos);
        Block block = BLOCK_STRIPPING_MAP.get(iblockstate.getBlock());
        if (block != null) {
            PlayerEntity entityplayer = p_195939_1_.getPlayer();
            world.playSound(entityplayer, blockpos, SoundEvents.ITEM_AXE_STRIP, SoundCategory.BLOCKS, 1.0F, 1.0F);
            if (!world.isRemote) {
                world.setBlockState(blockpos, block.getDefaultState().with(RotatedPillarBlock.AXIS, iblockstate.get(RotatedPillarBlock.AXIS)), 11);
                if (entityplayer != null) {
                    p_195939_1_.getItem().setDamage(1);
                }
            }

            return ActionResultType.SUCCESS;
        } else {
            return ActionResultType.PASS;
        }
    }


    @Override
    public boolean hasEffect(ItemStack p_77636_1_) {
        return true;
    }

    public float getAttackDamage() {
        return this.attackDamage;
    }

    public boolean canPlayerBreakBlockWhileHolding(BlockState p_195938_1_, World p_195938_2_, BlockPos p_195938_3_, PlayerEntity p_195938_4_) {
        return !p_195938_4_.isCreative();
    }

    public boolean hitEntity(ItemStack p_77644_1_, LivingEntity p_77644_2_, LivingEntity p_77644_3_) {
        p_77644_1_.setDamage(1);
        return true;
    }

    public boolean onBlockDestroyed(ItemStack p_179218_1_, World p_179218_2_, BlockState p_179218_3_, BlockPos p_179218_4_, LivingEntity p_179218_5_) {
        if (p_179218_3_.getBlockHardness(p_179218_2_, p_179218_4_) != 0.0F) {
            p_179218_1_.setDamage(2);
        }

        return true;
    }

    public boolean canHarvestBlock(BlockState p_150897_1_) {
        return p_150897_1_.getBlock() == Blocks.COBWEB;
    }

    public Multimap<String, AttributeModifier> getAttributeModifiers(EquipmentSlotType p_111205_1_) {
        Multimap<String, AttributeModifier> lvt_2_1_ = super.getAttributeModifiers(p_111205_1_);
        if (p_111205_1_ == EquipmentSlotType.MAINHAND) {
            lvt_2_1_.put(SharedMonsterAttributes.ATTACK_DAMAGE.getName(), new AttributeModifier(ATTACK_DAMAGE_MODIFIER, "Weapon modifier", (double)this.attackDamage, AttributeModifier.Operation.ADDITION));
            lvt_2_1_.put(SharedMonsterAttributes.ATTACK_SPEED.getName(), new AttributeModifier(ATTACK_SPEED_MODIFIER, "Weapon modifier", (double)this.attackSpeed, AttributeModifier.Operation.ADDITION));
        }

        return lvt_2_1_;
    }
}
