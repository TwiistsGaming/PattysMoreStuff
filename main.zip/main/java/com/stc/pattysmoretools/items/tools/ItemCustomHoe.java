package com.stc.pattysmoretools.items.tools;

import com.stc.pattysmoretools.PattysMoreTools;
import com.stc.pattysmoretools.init.ModItems;
import net.minecraft.item.IItemTier;
import net.minecraft.item.ItemStack;

public class ItemCustomHoe extends ItemStarHoe {
    public ItemCustomHoe(String name, IItemTier tier, float attackSpeedIn, Properties builder) {
        super(name, tier, attackSpeedIn, builder);
    }

    @Override
    public boolean hasEffect(ItemStack stack) {
        return false;
    }
}
