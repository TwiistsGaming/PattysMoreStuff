package com.stc.pattysmoretools.items.tools;

import com.stc.pattysmoretools.PattysMoreTools;
import com.stc.pattysmoretools.init.ModItems;
import net.minecraft.item.IItemTier;
import net.minecraft.item.ItemStack;

public class ItemCustomSpade extends ItemStarSpade {
    public ItemCustomSpade(String name, IItemTier tier, float attackDamageIn, float attackSpeedIn, Properties builder) {
        super(name, tier, attackDamageIn, attackSpeedIn, builder);

    }

    @Override
    public boolean hasEffect(ItemStack stack) {
        return false;
    }
}
