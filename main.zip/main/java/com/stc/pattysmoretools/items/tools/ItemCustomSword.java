package com.stc.pattysmoretools.items.tools;

import net.minecraft.item.IItemTier;
import net.minecraft.item.ItemStack;

public class ItemCustomSword extends ItemStarSword {
    public ItemCustomSword(String name, IItemTier tier, int attackDamageIn, float attackSpeedIn, Properties builder) {
        super(name, tier, attackDamageIn, attackSpeedIn, builder);
    }

    @Override
    public boolean hasEffect(ItemStack stack) {
        return false;
    }
}
