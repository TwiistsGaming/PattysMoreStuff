package com.stc.pattysmoretools.items.tools;

import com.stc.pattysmoretools.PattysMoreTools;
import com.stc.pattysmoretools.init.ModItems;
import net.minecraft.item.IItemTier;
import net.minecraft.item.ItemStack;

public class ItemBattleaxe extends ItemStarBattleaxe {
    public ItemBattleaxe(String name, IItemTier material, Properties builder) {
        super(name, material, builder);
    }

    @Override
    public boolean hasEffect(ItemStack p_77636_1_) {
        return false;
    }
}
