package com.stc.pattysmoretools.items;

import com.stc.pattysmoretools.PattysMoreTools;
import com.stc.pattysmoretools.init.ModItems;
import net.minecraft.item.Item;

public class ItemObsidianIngot extends Item {
    public ItemObsidianIngot(String name, Properties properties) {
        super(properties);
        this.setRegistryName(PattysMoreTools.MODID, name);

        ModItems.ITEMS.add(this);

    }
}
