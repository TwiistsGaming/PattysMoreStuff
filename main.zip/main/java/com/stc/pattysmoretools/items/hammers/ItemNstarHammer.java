package com.stc.pattysmoretools.items.hammers;

import com.stc.pattysmoretools.PattysMoreTools;
import com.stc.pattysmoretools.config.ConfigGeneral;
import com.stc.pattysmoretools.init.ModItems;
import com.stc.pattysmoretools.items.tools.PMTTool;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.IItemTier;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.PickaxeItem;
import net.minecraft.util.math.*;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import net.minecraftforge.common.ToolType;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.List;

public class ItemNstarHammer extends PickaxeItem implements PMTTool {

    public ItemNstarHammer(String name, IItemTier tier, int attackDamageIn, float attackSpeedIn, Item.Properties builder) {
        super(tier, attackDamageIn, attackSpeedIn, builder);

        this.setRegistryName(PattysMoreTools.MODID, name);
        if(ConfigGeneral.disableHammers.get()) {

            ModItems.ITEMS.add(this);
        }
    }

    @Nonnull
    @Override
    public ToolType getPMTToolClass() {
        return ToolType.PICKAXE;
    }

    @Nullable
    @Override
    public RayTraceResult rayTraceBlocks(World world, PlayerEntity player) {
        return rayTrace(world, player, RayTraceContext.FluidMode.NONE);
    }

    @Override
    public boolean onBlockStartBreak(ItemStack itemstack, BlockPos pos, PlayerEntity player) {
        return PMTTool.BreakHandler.onBlockStartBreak(itemstack, pos, player);
    }

    @Override
    public void addInformation(ItemStack stack, @Nullable World worldIn, List<ITextComponent> tooltip, ITooltipFlag flagIn) {
        tooltip.add(new StringTextComponent(TextFormatting.GREEN  + "Hammer that mines in a 3x3x1 from the block you mine"));
    }

    @Override
    public boolean hasEffect(ItemStack stack) {
        return true;
    }
}
