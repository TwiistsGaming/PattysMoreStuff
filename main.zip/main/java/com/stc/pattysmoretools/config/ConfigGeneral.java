package com.stc.pattysmoretools.config;

import net.minecraftforge.common.ForgeConfigSpec;

public class ConfigGeneral {


    public static ForgeConfigSpec.BooleanValue disableTools;
    public static ForgeConfigSpec.BooleanValue disableBows;
    public static ForgeConfigSpec.BooleanValue disableHammers;
    public static ForgeConfigSpec.BooleanValue disableScythes;
    public static ForgeConfigSpec.BooleanValue disableExcavator;
    public static ForgeConfigSpec.BooleanValue disablePaxel;
    public static ForgeConfigSpec.BooleanValue disableLumberAxe;


    public static void init(ForgeConfigSpec.Builder builder){

        builder.comment("Enable or disable tools").push("Tools");
        disableTools = builder
                .comment("Setting this to false will disable all the tools [true /false default: true]")
                .define("EnableTools", true);
        builder.pop();
        builder.comment("Enable or disable Bows").push("Bows");
        disableBows = builder
                .comment("Setting this to false will disable all the bows [true /false default: true]")
                .define("EnableBows", true);
        builder.pop();
        builder.comment("Enable or disable Hammers").push("Hammers");
        disableHammers = builder
                .comment("Setting this to false will disable all the hammers [true /false default: true]")
                .define("EnableHammers", true);
        builder.pop();
        builder.comment("Enable or disable Scythes").push("Scythes");
        disableScythes = builder
                .comment("Setting this to false will disable all the scythes [true /false default: true]")
                .define("EnableScythes", true);
        builder.pop();
        builder.comment("Enable or disable Excavator").push("Excavator");
        disableExcavator = builder
                .comment("Setting this to false will disable all the excavators [true /false default: true]")
                .define("EnableExcavator", true);
        builder.pop();
        builder.comment("Enable or disable Paxel").push("Paxel");
        disablePaxel = builder
                .comment("Setting this to false will disable all the paxels [true /false default: true]")
                .define("EnablePaxel", true);
        builder.pop();
        builder.comment("Enable or disable Lumber Axe").push("LumberAxes");
        disableLumberAxe = builder
                .comment("Setting this to false will disable all the lumber axes [true /false default: true]")
                .define("EnableLumberAxe", true);
        builder.pop();

    }
}
