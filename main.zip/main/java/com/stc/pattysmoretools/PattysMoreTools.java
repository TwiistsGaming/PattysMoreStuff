package com.stc.pattysmoretools;

import com.stc.pattysmoretools.config.CoreConfig;
import com.stc.pattysmoretools.init.ModTabs;
import com.stc.pattysmoretools.network.ClientProxy;
import com.stc.pattysmoretools.network.IProxy;
import com.stc.pattysmoretools.network.ServerProxy;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.loading.FMLPaths;

@Mod(value = PattysMoreTools.MODID)
public class PattysMoreTools
{

    public static final String MODID = "pattysmoretools";
    public static PattysMoreTools instance;
    public static IProxy proxy = DistExecutor.runForDist(() -> () -> new ClientProxy(), () -> () -> new ServerProxy());

    public PattysMoreTools() {
        instance = this;

        ModLoadingContext.get().registerConfig(ModConfig.Type.SERVER, CoreConfig.SPEC, "PattysMoreTools-General.toml");
        CoreConfig.loadConfig(CoreConfig.SPEC, FMLPaths.CONFIGDIR.get().resolve("PattysMoreTools-General.toml".toString()));

        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::preInit);
        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::init);
        MinecraftForge.EVENT_BUS.register(this);
        ModTabs.pattysTabs();

    }

    private void preInit(final FMLCommonSetupEvent event)
    {
        proxy.setup(event);
    }

    private void init(final FMLClientSetupEvent event){

    }

    public static ResourceLocation getId(String path) {
        return new ResourceLocation(MODID, path);
    }

}
